/*!@license
* Infragistics.Web.ClientUI Doughnut Chart localization resources 21.2.20212.48
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.tr=$.ig.locale.tr||{};$.ig.igDoughnutChart=$.ig.igDoughnutChart||{};$.ig.locale.tr.igDoughnutChart={invalidBaseElement:" temel öğe olarak desteklenmez. Bunun yerine DIV kullanın."};$.ig.igDoughnutChart.locale=$.ig.igDoughnutChart.locale||$.ig.locale.tr.igDoughnutChart;return $.ig.locale.tr.igDoughnutChart});