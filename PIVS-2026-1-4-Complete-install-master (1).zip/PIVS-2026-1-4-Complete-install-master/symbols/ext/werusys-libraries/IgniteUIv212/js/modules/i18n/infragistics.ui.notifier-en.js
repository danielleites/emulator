/*!@license
* Infragistics.Web.ClientUI Notifier localization resources 21.2.9
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.en=$.ig.locale.en||{};$.ig.Notifier=$.ig.Notifier||{};$.ig.locale.en.Notifier={successMsg:"Success",errorMsg:"Error",warningMsg:"Warning",infoMsg:"Information",notSupportedState:"Not supported notification state! Use one of the supported states 'success', 'info', 'warning', 'error'",notSupportedMode:"Not supported notification mode! Use one of the supported modes 'auto', 'popover', 'inline'"};$.ig.Notifier.locale=$.ig.Notifier.locale||$.ig.locale.en.Notifier;return $.ig.locale.en.Notifier});