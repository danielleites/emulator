/*!@license
* Infragistics.Web.ClientUI Bullet Graph localization resources 21.2.20212.48
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.cs=$.ig.locale.cs||{};$.ig.BulletGraph=$.ig.BulletGraph||{};$.ig.locale.cs.BulletGraph={rangeNameMissing:"Pro rozsah chyb� n�zev rozsahu: "};$.ig.BulletGraph.locale=$.ig.BulletGraph.locale||$.ig.locale.cs.BulletGraph;return $.ig.locale.cs.BulletGraph});