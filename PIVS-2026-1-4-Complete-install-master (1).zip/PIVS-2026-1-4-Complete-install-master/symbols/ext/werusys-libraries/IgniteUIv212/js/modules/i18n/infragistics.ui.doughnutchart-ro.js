/*!@license
* Infragistics.Web.ClientUI Doughnut Chart localization resources 21.2.20212.48
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.ro=$.ig.locale.ro||{};$.ig.igDoughnutChart=$.ig.igDoughnutChart||{};$.ig.locale.ro.igDoughnutChart={invalidBaseElement:" nu este acceptat ca element de bază. Folosiți în schimb DIV."};$.ig.igDoughnutChart.locale=$.ig.igDoughnutChart.locale||$.ig.locale.ro.igDoughnutChart;return $.ig.locale.ro.igDoughnutChart});