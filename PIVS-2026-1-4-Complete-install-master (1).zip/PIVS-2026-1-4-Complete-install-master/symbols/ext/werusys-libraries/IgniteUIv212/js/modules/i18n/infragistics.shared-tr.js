/*!@license
* Infragistics.Web.ClientUI shared localization resources 21.2.9
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.tr=$.ig.locale.tr||{};$.ig.SharedLocale=$.ig.SharedLocale||{};$.ig.locale.tr.SharedLocale={};$.ig.SharedLocale.locale=$.ig.SharedLocale.locale||$.ig.locale.tr.SharedLocale;return $.ig.locale.tr.SharedLocale});