/*!@license
* Infragistics.Web.ClientUI Linear Gauge localization resources 21.2.20212.48
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.nb=$.ig.locale.nb||{};$.ig.LinearGauge=$.ig.LinearGauge||{};$.ig.locale.nb.LinearGauge={rangeNameMissing:"Omr�denavn mangler for omr�de: "};$.ig.LinearGauge.locale=$.ig.LinearGauge.locale||$.ig.locale.nb.LinearGauge;return $.ig.locale.nb.LinearGauge});