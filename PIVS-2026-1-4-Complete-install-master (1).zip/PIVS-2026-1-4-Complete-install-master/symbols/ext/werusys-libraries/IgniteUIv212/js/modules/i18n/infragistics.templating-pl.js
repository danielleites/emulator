/*!@license
* Infragistics.Web.ClientUI templating localization resources 21.2.9
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.pl=$.ig.locale.pl||{};$.ig.Templating=$.ig.Templating||{};$.ig.locale.pl.Templating={undefinedArgument:"Wystąpił błąd podczas próby pobrania właściwości źródła danych: "};$.ig.Templating.locale=$.ig.Templating.locale||$.ig.locale.pl.Templating;return $.ig.locale.pl.Templating});