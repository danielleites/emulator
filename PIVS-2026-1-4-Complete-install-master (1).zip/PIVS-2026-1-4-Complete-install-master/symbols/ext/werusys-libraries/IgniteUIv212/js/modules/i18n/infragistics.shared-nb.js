/*!@license
* Infragistics.Web.ClientUI shared localization resources 21.2.9
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.nb=$.ig.locale.nb||{};$.ig.SharedLocale=$.ig.SharedLocale||{};$.ig.locale.nb.SharedLocale={};$.ig.SharedLocale.locale=$.ig.SharedLocale.locale||$.ig.locale.nb.SharedLocale;return $.ig.locale.nb.SharedLocale});