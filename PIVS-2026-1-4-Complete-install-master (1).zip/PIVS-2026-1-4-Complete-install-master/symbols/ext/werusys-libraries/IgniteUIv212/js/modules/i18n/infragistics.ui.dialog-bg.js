/*!@license
* Infragistics.Web.ClientUI Dialog localization resources 21.2.9
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.bg=$.ig.locale.bg||{};$.ig.Dialog=$.ig.Dialog||{};$.ig.locale.bg.Dialog={closeButtonTitle:"Затвори",minimizeButtonTitle:"Минимизирай",maximizeButtonTitle:"Максимизирай",pinButtonTitle:"Закачи",unpinButtonTitle:"Откачи",restoreButtonTitle:"Възстанови",setOptionError:"Тази опцията не може да бъде настроена по време на изпълнение."};$.ig.Dialog.locale=$.ig.Dialog.locale||$.ig.locale.bg.Dialog;return $.ig.locale.bg.Dialog});