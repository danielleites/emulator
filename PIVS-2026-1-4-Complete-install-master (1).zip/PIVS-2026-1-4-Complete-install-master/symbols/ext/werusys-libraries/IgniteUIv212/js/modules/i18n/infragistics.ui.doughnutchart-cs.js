/*!@license
* Infragistics.Web.ClientUI Doughnut Chart localization resources 21.2.20212.48
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.cs=$.ig.locale.cs||{};$.ig.igDoughnutChart=$.ig.igDoughnutChart||{};$.ig.locale.cs.igDoughnutChart={invalidBaseElement:" není podporován jako základní prvek. Místo toho použijte DIV."};$.ig.igDoughnutChart.locale=$.ig.igDoughnutChart.locale||$.ig.locale.cs.igDoughnutChart;return $.ig.locale.cs.igDoughnutChart});