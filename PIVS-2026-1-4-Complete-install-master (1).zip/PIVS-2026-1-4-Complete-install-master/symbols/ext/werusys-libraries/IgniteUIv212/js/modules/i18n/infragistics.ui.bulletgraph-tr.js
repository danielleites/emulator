/*!@license
* Infragistics.Web.ClientUI Bullet Graph localization resources 21.2.20212.48
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.tr=$.ig.locale.tr||{};$.ig.BulletGraph=$.ig.BulletGraph||{};$.ig.locale.tr.BulletGraph={rangeNameMissing:"Aral�k i�in aral�k ad� eksik: "};$.ig.BulletGraph.locale=$.ig.BulletGraph.locale||$.ig.locale.tr.BulletGraph;return $.ig.locale.tr.BulletGraph});