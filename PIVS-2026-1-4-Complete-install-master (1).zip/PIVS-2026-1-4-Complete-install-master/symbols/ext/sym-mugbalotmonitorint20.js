/**
 * ═══════════════════════════════════════════════════════
 *  sym-mugbalotmonitorint20.js  —  Symbol Orchestrator (INT variant)
 * ═══════════════════════════════════════════════════════
 *  Identical logic to mugbalotmonitor20, different typeName.
 *  Shares mm20-plugins/*.js widgets — loaded via template.
 *
 *  DEFENSIVE LOADING:
 *    If mm20-plugins/ files are missing, this symbol renders
 *    a Hebrew error fallback inside its own container and
 *    does NOT crash any other symbol on the display.
 *
 *  Version : 20.0.R1-INT
 *  ES5 only — IE11 compatible
 *  Inject  : $interval, $timeout
 * ═══════════════════════════════════════════════════════
 */
(function (PV) {
    'use strict';

    // ── Symbol constructor ──
    function symbolVis() {}
    PV.deriveVisualizationFromBase(symbolVis);


    // ═══════════════════════════════════════
    //  INIT
    // ═══════════════════════════════════════

    symbolVis.prototype.init = function (scope, el, $interval, $timeout) {

        var MM = window.MM20;

        // ── DEFENSIVE GUARD ──────────────────────────────────
        // If shared core is missing, render Hebrew error inside
        // the symbol container and bail out safely. No crash.
        if (!MM) {
            console.error('[MM20-INT] mm20-core.js not loaded — symbol cannot initialize.');
            try {
                var rootDiv = el[0].querySelector('.mm20-root') || el[0];
                rootDiv.innerHTML =
                    '<div dir="rtl" style="display:flex;align-items:center;justify-content:center;' +
                    'height:100%;color:#F39C12;text-align:center;padding:20px;font-family:Segoe UI,Arial,sans-serif;">' +
                    '<div><div style="font-size:32px;margin-bottom:8px;">\u26A0</div>' +
                    '<div style="font-size:14px;font-weight:600;">\u05EA\u05E9\u05EA\u05D9\u05EA MM20 \u05DC\u05D0 \u05E0\u05D8\u05E2\u05E0\u05D4</div>' +
                    '<div style="font-size:11px;color:#8899AA;margin-top:4px;">' +
                    '\u05D4\u05EA\u05D9\u05E7\u05D9\u05D9\u05D4 mm20-plugins \u05D7\u05E1\u05E8\u05D4. \u05D5\u05D3\u05D0 \u05E9\u05D4\u05E7\u05D1\u05E6\u05D9\u05DD \u05E7\u05D9\u05D9\u05DE\u05D9\u05DD \u05D1\u05EA\u05D9\u05E7\u05D9\u05D9\u05EA ext.</div>' +
                    '</div></div>';
            } catch (ignore) {}
            return;
        }

        // ── Instance state ──
        var _destroyed   = false;
        var _bus         = MM.createBus();
        var _demoMode    = !!scope.config.DemoMode;
        var _sites       = (scope.config.CustomSites && scope.config.CustomSites.length)
                           ? scope.config.CustomSites
                           : MM.SITES;
        var _parsedData  = {};       // { siteId: { unitIdx: {...} } }
        var _prevHours   = {};       // { unitKey: { hours, ts } } — for TTE rate tracking
        var _refreshHandle = null;
        var _pendingXhrs = [];
        var _unwatchers  = [];
        var _timeouts    = [];
        var _rootEl      = el[0].querySelector('.mm20-root') || el[0];

        // ── Widget references ──
        var _wSiteGrid   = null;
        var _wHeatmap    = null;
        var _wReports    = null;
        var _wAlerts     = null;
        var _wLog        = null;


        // ─────────────────────────────────────
        //  Apply theme CSS custom properties
        // ─────────────────────────────────────
        MM.applyTheme(_rootEl, scope.config);


        // ─────────────────────────────────────
        //  PI Connection Check (10s sentinel)
        // ─────────────────────────────────────
        var _checkConnection = function () {
            try {
                var xhr = new XMLHttpRequest();
                xhr.open('HEAD', '/piwebapi/system', true);
                xhr.timeout = 10000;
                xhr.onload = function () {
                    if (xhr.status >= 200 && xhr.status < 400) {
                        _setDemoMode(false);
                        _log('info', '\u05D7\u05D9\u05D1\u05D5\u05E8 PI Web API \u05EA\u05E7\u05D9\u05DF');
                    } else {
                        _setDemoMode(true);
                        _log('warn', '\u05E9\u05E8\u05EA PI Web API \u05DC\u05D0 \u05D6\u05DE\u05D9\u05DF (HTTP ' + xhr.status + ')');
                    }
                };
                xhr.onerror = xhr.ontimeout = function () {
                    _setDemoMode(true);
                    _log('warn', '\u05E9\u05E8\u05EA PI Web API \u05DC\u05D0 \u05D6\u05DE\u05D9\u05DF \u2014 \u05DE\u05E6\u05D1 \u05D3\u05DE\u05D5');
                };
                _pendingXhrs.push(xhr);
                xhr.send();
            } catch (e) {
                _setDemoMode(true);
            }
        };

        var _setDemoMode = function (enabled) {
            _demoMode = enabled;
            scope.config.DemoMode = enabled;
            _bus.emit('demo:toggle', { enabled: enabled });
        };


        // ─────────────────────────────────────
        //  System logging helper (with startup buffer)
        // ─────────────────────────────────────
        var _logBuffer = [];   // holds entries emitted before log widget subscribes
        var _logReady  = false;

        var _log = function (level, msg) {
            var entry = {
                level: level,
                source: 'orchestrator-int',
                msg: msg,
                ts: new Date().toISOString()
            };
            if (_logReady) {
                _bus.emit('log:entry', entry);
            } else {
                _logBuffer.push(entry);
            }
        };

        var _flushLogBuffer = function () {
            _logReady = true;
            for (var i = 0; i < _logBuffer.length; i++) {
                _bus.emit('log:entry', _logBuffer[i]);
            }
            _logBuffer.length = 0;
        };


        // ─────────────────────────────────────
        //  Widget Instantiation
        // ─────────────────────────────────────
        var _initWidgets = function () {
            var $ = window.jQuery;
            if (!$) {
                MM.shield.log('orchestrator-int', '_initWidgets', new Error('jQuery not available'));
                return;
            }

            try {
                // siteGrid — Realtime tab
                var gridEl = $('#mm20-siteGrid', el);
                if (gridEl.length && $.fn.mm20SiteGrid) {
                    gridEl.mm20SiteGrid({
                        bus:        _bus,
                        sites:      _sites,
                        demoMode:   _demoMode,
                        favorites:  scope.config.Favorites || {},
                        sortOrder:  scope.config.SortOrder || 'name',
                        warnPct:    scope.config.WarnPct || 70,
                        critPct:    scope.config.CritPct || 90,
                        showSparklines: scope.config.ShowSparklines !== false,
                        decimals:   scope.config.Decimals || 1,
                        annotations: scope.config.Annotations || {}
                    });
                    _wSiteGrid = gridEl;
                }
            } catch (e) { MM.shield.log('orchestrator-int', 'init:siteGrid', e); }

            try {
                // heatmap — Heatmap tab
                var hmEl = $('#mm20-heatmap', el);
                if (hmEl.length && $.fn.mm20Heatmap) {
                    hmEl.mm20Heatmap({
                        bus:      _bus,
                        sites:    _sites,
                        demoMode: _demoMode,
                        metric:   scope.config.HeatmapMetric || 'hours',
                        siteFilter: scope.config.HeatmapSite || ''
                    });
                    _wHeatmap = hmEl;
                }
            } catch (e) { MM.shield.log('orchestrator-int', 'init:heatmap', e); }

            try {
                // reports — Reports tab
                var repEl = $('#mm20-reports', el);
                if (repEl.length && $.fn.mm20Reports) {
                    repEl.mm20Reports({
                        bus:      _bus,
                        sites:    _sites,
                        demoMode: _demoMode,
                        template: scope.config.ReportTemplate || 'monthly',
                        grouping: scope.config.ReportGrouping || 'site'
                    });
                    _wReports = repEl;
                }
            } catch (e) { MM.shield.log('orchestrator-int', 'init:reports', e); }

            try {
                // alerts — Alerts tab
                var alertEl = $('#mm20-alerts', el);
                if (alertEl.length && $.fn.mm20Alerts) {
                    alertEl.mm20Alerts({
                        bus:       _bus,
                        sites:     _sites,
                        demoMode:  _demoMode,
                        quotaPct:  scope.config.AlertQuotaPct || 90,
                        hoursMax:  scope.config.AlertHoursMax || 1000,
                        staleSec:  scope.config.AlertStaleSec || 300,
                        soundEnabled: !!scope.config.AlertSoundEnabled,
                        pushEnabled:  !!scope.config.PushNotificationsEnabled
                    });
                    _wAlerts = alertEl;
                }
            } catch (e) { MM.shield.log('orchestrator-int', 'init:alerts', e); }

            try {
                // log — Log tab
                var logEl = $('#mm20-log', el);
                if (logEl.length && $.fn.mm20LogViewer) {
                    logEl.mm20LogViewer({
                        bus:        _bus,
                        maxEntries: scope.config.MaxLogEntries || 500
                    });
                    _wLog = logEl;
                }
            } catch (e) { MM.shield.log('orchestrator-int', 'init:log', e); }
        };


        // ─────────────────────────────────────
        //  Tab Switching
        // ─────────────────────────────────────
        scope.switchTab = function (tab) {
            scope.config.ActiveTab = tab;
            _bus.emit('tab:changed', { tab: tab });
        };


        // ─────────────────────────────────────
        //  Keyboard Shortcuts
        // ─────────────────────────────────────
        var _onKeydown = function (e) {
            if (_destroyed) return;
            // Only handle when this symbol has focus (strict containment check)
            if (!el[0].contains(document.activeElement)) return;

            // Ctrl+K → global search
            if (e.ctrlKey && e.keyCode === 75) {
                e.preventDefault();
                _bus.emit('search:query', { open: true });
                return;
            }
            // Escape → close overlays
            if (e.keyCode === 27) {
                _bus.emit('search:query', { open: false });
                return;
            }
            // Number keys 1-7 → tab switch
            if (!e.ctrlKey && !e.altKey && e.keyCode >= 49 && e.keyCode <= 55) {
                var tabs = ['realtime', 'heatmap', 'reports', 'alerts', 'log', 'tags', 'afbuild'];
                var idx = e.keyCode - 49;
                if (tabs[idx]) {
                    scope.switchTab(tabs[idx]);
                    try { scope.$apply(); } catch (ex) { /* safe */ }
                }
            }
        };
        document.addEventListener('keydown', _onKeydown);


        // ─────────────────────────────────────
        //  Viewport Guard (IntersectionObserver)
        // ─────────────────────────────────────
        var _observer = null;
        var _isVisible = true;

        if (typeof IntersectionObserver !== 'undefined') {
            _observer = new IntersectionObserver(function (entries) {
                _isVisible = entries[0].isIntersecting;
                if (!_isVisible && _refreshHandle) {
                    $interval.cancel(_refreshHandle);
                    _refreshHandle = null;
                } else if (_isVisible && !_refreshHandle && scope.config.EnableAutoRefresh) {
                    _startRefresh();
                }
            }, { threshold: 0.1 });
            _observer.observe(el[0]);
        }


        // ─────────────────────────────────────
        //  Auto-Refresh Timer
        // ─────────────────────────────────────
        var _startRefresh = function () {
            if (_refreshHandle) $interval.cancel(_refreshHandle);
            var sec = (scope.config.RefreshInterval || 30) * 1000;
            _refreshHandle = $interval(function () {
                if (_demoMode && _wSiteGrid) {
                    var fakeData = MM.demo.generateSites(_sites);
                    _parsedData = fakeData;
                    _forwardData(fakeData);
                }
                // Real data comes from PI Vision's dataUpdate — no need to fetch here
            }, sec);
        };

        if (scope.config.EnableAutoRefresh !== false) {
            _startRefresh();
        }

        // Watch config changes for refresh interval
        _unwatchers.push(scope.$watch('config.RefreshInterval', function (nv) {
            if (nv && scope.config.EnableAutoRefresh) _startRefresh();
        }));
        _unwatchers.push(scope.$watch('config.EnableAutoRefresh', function (nv) {
            if (nv) { _startRefresh(); }
            else if (_refreshHandle) { $interval.cancel(_refreshHandle); _refreshHandle = null; }
        }));


        // ─────────────────────────────────────
        //  Forward parsed data to widgets
        // ─────────────────────────────────────
        var _forwardData = function (parsed) {
            if (_wSiteGrid && window.jQuery.fn.mm20SiteGrid) {
                try { _wSiteGrid.mm20SiteGrid('option', 'data', parsed); } catch (e) { MM.shield.log('orchestrator-int', 'forward:siteGrid', e); }
            }
            if (_wAlerts && window.jQuery.fn.mm20Alerts) {
                try { _wAlerts.mm20Alerts('option', 'data', parsed); } catch (e) { MM.shield.log('orchestrator-int', 'forward:alerts', e); }
            }
            if (_wHeatmap && window.jQuery.fn.mm20Heatmap) {
                try { _wHeatmap.mm20Heatmap('option', 'data', parsed); } catch (e) { MM.shield.log('orchestrator-int', 'forward:heatmap', e); }
            }
            if (_wReports && window.jQuery.fn.mm20Reports) {
                try { _wReports.mm20Reports('option', 'data', parsed); } catch (e) { MM.shield.log('orchestrator-int', 'forward:reports', e); }
            }
            _bus.emit('data:updated', { sites: parsed, ts: new Date().toISOString() });
        };


        // ─────────────────────────────────────
        //  Config → Widget bridge
        // ─────────────────────────────────────
        var _syncConfig = function () {
            MM.applyTheme(_rootEl, scope.config);
            _bus.emit('config:changed', { config: scope.config });
        };

        _unwatchers.push(scope.$watchCollection('config', function () {
            if (!_destroyed) _syncConfig();
        }));


        // ─────────────────────────────────────
        //  Config Import / Export
        // ─────────────────────────────────────
        scope.exportConfig = function () {
            var json = JSON.stringify(scope.config, null, 2);
            var blob = new Blob([json], { type: 'application/json' });
            var url  = URL.createObjectURL(blob);
            var a    = document.createElement('a');
            a.href = url;
            a.download = 'mm20int-config-' + MM.formatDate(new Date(), 'date').replace(/\//g, '-') + '.json';
            a.click();
            setTimeout(function () { URL.revokeObjectURL(url); }, 100);
            _log('info', '\u05EA\u05E6\u05D5\u05E8\u05D4 \u05D9\u05D5\u05E6\u05D0\u05D4');
        };

        scope.importConfig = function (jsonStr) {
            try {
                var imported = JSON.parse(jsonStr);
                for (var key in imported) {
                    if (imported.hasOwnProperty(key)) {
                        scope.config[key] = imported[key];
                    }
                }
                _sites = (scope.config.CustomSites && scope.config.CustomSites.length)
                         ? scope.config.CustomSites : MM.SITES;
                _syncConfig();
                _log('info', '\u05EA\u05E6\u05D5\u05E8\u05D4 \u05D9\u05D5\u05D1\u05D0\u05D4 \u05D1\u05D4\u05E6\u05DC\u05D7\u05D4');
            } catch (e) {
                _log('error', '\u05E9\u05D2\u05D9\u05D0\u05D4 \u05D1\u05D9\u05D9\u05D1\u05D5\u05D0 \u05EA\u05E6\u05D5\u05E8\u05D4: ' + e.message);
            }
        };

        /**
         * Import config from a File object (called by config panel file input).
         * Reads the file via FileReader and delegates to importConfig().
         */
        scope.importConfigFile = function (file) {
            if (!file) return;
            try {
                var reader = new FileReader();
                reader.onload = function (e) {
                    scope.importConfig(e.target.result);
                    try { scope.$apply(); } catch (ex) { /* safe */ }
                };
                reader.onerror = function () {
                    _log('error', '\u05E9\u05D2\u05D9\u05D0\u05D4 \u05D1\u05E7\u05E8\u05D9\u05D0\u05EA \u05E7\u05D5\u05D1\u05E5');
                };
                reader.readAsText(file);
            } catch (e) {
                _log('error', '\u05E9\u05D2\u05D9\u05D0\u05D4 \u05D1\u05D9\u05D9\u05D1\u05D5\u05D0 \u05E7\u05D5\u05D1\u05E5: ' + e.message);
            }
        };


        // ─────────────────────────────────────
        //  Startup sequence
        // ─────────────────────────────────────
        _checkConnection();

        // Delay widget creation slightly to allow script tags to load
        var _initTimeout = $timeout(function () {
            if (_destroyed) return;
            _initWidgets();
            // Flush buffered log entries now that log widget is subscribed
            _flushLogBuffer();
            // Seed demo data if in demo mode
            if (_demoMode) {
                var seed = MM.demo.generateSites(_sites);
                _parsedData = seed;
                _forwardData(seed);
            }
            _log('info', 'Mugbalot Monitor v' + MM.VERSION + '-INT \u05D0\u05D5\u05EA\u05D7\u05DC');
        }, 200);
        _timeouts.push(_initTimeout);


        // ═══════════════════════════════════════
        //  DATA UPDATE  (called by PI Vision)
        // ═══════════════════════════════════════

        this.dataUpdate = MM.shield.wrap('orchestrator-int', 'dataUpdate', function (data) {
            if (_destroyed || !data) return;

            // Demo mode: ignore real data, use generated
            if (_demoMode) return;

            // Parse PI Vision data array into site/unit structure
            var parsed = _parseData(data);
            if (parsed) {
                _parsedData = parsed;
                _forwardData(parsed);
            }
        });

        /**
         * Parse PI Vision data.Data array into structured format.
         * Each DataSource path is matched to a site/unit.
         *
         * Expected path format:
         *   \\AF\Server\Database\Plants\{SiteName}\{UnitName}|AttributeName
         *
         * @param {Object} data - PI Vision data object
         * @returns {Object|null} { siteId: { unitIdx: { hours, quota, pct, ... } } }
         */
        var _parseData = function (data) {
            if (!data || !data.Data) return null;

            var result = {};
            var dataArr = data.Data;

            for (var i = 0; i < dataArr.length; i++) {
                var item = dataArr[i];
                if (!item || !item.Path) continue;

                var path = item.Path;
                var value = (item.Value !== undefined) ? Number(item.Value) : NaN;
                if (isNaN(value)) continue;

                // Try to match path to site/unit
                var match = _matchPath(path);
                if (!match) continue;

                if (!result[match.siteId]) result[match.siteId] = {};
                if (!result[match.siteId][match.unitIdx]) {
                    result[match.siteId][match.unitIdx] = {
                        hours: 0, quota: 0, pct: 0, status: 'ok', tte: 0,
                        ts: item.Timestamp || new Date().toISOString(),
                        monthly: []
                    };
                }

                var unit = result[match.siteId][match.unitIdx];
                // Map attribute name to field
                var attr = match.attr.toLowerCase();
                if (attr.indexOf('hour') >= 0 || attr.indexOf('\u05E9\u05E2') >= 0) {
                    unit.hours = value;
                } else if (attr.indexOf('quot') >= 0 || attr.indexOf('\u05DE\u05DB\u05E1') >= 0) {
                    unit.quota = value;
                }

                // Recalculate derived fields
                if (unit.quota > 0) {
                    unit.pct = Math.round((unit.hours / unit.quota) * 1000) / 10;
                    unit.status = MM.getStatus(unit.pct, scope.config.WarnPct, scope.config.CritPct);

                    // TTE: compute rate from previous dataUpdate snapshot
                    var unitKey = MM.unitKey(match.siteId, match.unitIdx);
                    var prev = _prevHours[unitKey];
                    var nowMs = new Date().getTime();
                    var rate = 0;
                    if (prev && prev.hours !== undefined) {
                        var dtMs = nowMs - prev.ts;
                        if (dtMs > 0) {
                            rate = MM.stats.rateOfChange(prev.hours, unit.hours, dtMs);
                        }
                    }
                    _prevHours[unitKey] = { hours: unit.hours, ts: nowMs };
                    unit.tte = MM.stats.forecast(unit.hours, rate, unit.quota);
                }
            }

            return result;
        };

        /**
         * Match an AF path to a site/unit.
         * Uses fuzzy token matching against SITES array.
         */
        var _pathCache = {};
        var _matchPath = function (path) {
            if (_pathCache[path]) return _pathCache[path];

            // Extract components from path
            var segments = path.split('\\').filter(function (s) { return s.length > 0; });
            var attrPart = '';
            var pipIdx = path.indexOf('|');
            if (pipIdx >= 0) {
                attrPart = path.substring(pipIdx + 1);
            }

            // Try to find site/unit by name matching
            for (var s = 0; s < _sites.length; s++) {
                var site = _sites[s];
                // Check if path contains site name or site id
                if (path.indexOf(site.name) >= 0 || path.indexOf(site.id) >= 0) {
                    // Find unit
                    for (var u = 0; u < site.units.length; u++) {
                        if (path.indexOf(site.units[u]) >= 0) {
                            var match = { siteId: site.id, unitIdx: u, attr: attrPart };
                            _pathCache[path] = match;
                            return match;
                        }
                    }
                    // Site found but no specific unit match → unit 0
                    var fallback = { siteId: site.id, unitIdx: 0, attr: attrPart };
                    _pathCache[path] = fallback;
                    return fallback;
                }
            }
            return null;
        };


        // ═══════════════════════════════════════
        //  RESIZE
        // ═══════════════════════════════════════

        this.onResize = function () {
            if (_destroyed) return;
            _bus.emit('resize', {});
        };


        // ═══════════════════════════════════════
        //  $DESTROY — Resource Cleanup
        // ═══════════════════════════════════════

        scope.$on('$destroy', function () {
            _destroyed = true;

            // Cancel refresh interval
            if (_refreshHandle) {
                $interval.cancel(_refreshHandle);
                _refreshHandle = null;
            }

            // Cancel all $timeout handles
            for (var t = 0; t < _timeouts.length; t++) {
                try { $timeout.cancel(_timeouts[t]); } catch (e) { /* safe */ }
            }
            _timeouts.length = 0;

            // Deregister watchers
            for (var w = 0; w < _unwatchers.length; w++) {
                try { _unwatchers[w](); } catch (e) { /* safe */ }
            }
            _unwatchers.length = 0;

            // Abort pending XHRs
            for (var x = 0; x < _pendingXhrs.length; x++) {
                try { _pendingXhrs[x].abort(); } catch (e) { /* safe */ }
            }
            _pendingXhrs.length = 0;

            // Remove keyboard listener
            document.removeEventListener('keydown', _onKeydown);

            // Disconnect viewport observer
            if (_observer) {
                _observer.disconnect();
                _observer = null;
            }

            // Destroy jQuery widgets
            var $ = window.jQuery;
            if ($) {
                if (_wSiteGrid && $.fn.mm20SiteGrid) try { _wSiteGrid.mm20SiteGrid('destroy'); } catch (e) {}
                if (_wHeatmap  && $.fn.mm20Heatmap)  try { _wHeatmap.mm20Heatmap('destroy'); } catch (e) {}
                if (_wReports  && $.fn.mm20Reports)  try { _wReports.mm20Reports('destroy'); } catch (e) {}
                if (_wAlerts   && $.fn.mm20Alerts)   try { _wAlerts.mm20Alerts('destroy'); } catch (e) {}
                if (_wLog      && $.fn.mm20LogViewer) try { _wLog.mm20LogViewer('destroy'); } catch (e) {}
            }

            // Log before bus reset (so log widget still receives it)
            _log('info', '\u05E1\u05D9\u05DE\u05D1\u05D5\u05DC \u05E0\u05D4\u05E8\u05E1 \u2014 \u05E0\u05D9\u05E7\u05D5\u05D9 \u05DE\u05E9\u05D0\u05D1\u05D9\u05DD');

            // Reset bus (drop all subscriptions)
            _bus.reset();
        });
    };


    // ═══════════════════════════════════════
    //  REGISTRATION
    // ═══════════════════════════════════════

    var def = {
        typeName: 'mugbalotmonitorint20',
        displayName: '\u05E0\u05D9\u05D8\u05D5\u05E8 \u05DE\u05D5\u05D2\u05D1\u05DC\u05D5\u05EA v20-INT \u2014 \u05E9\u05E2\u05D5\u05EA \u05E2\u05D1\u05D5\u05D3\u05D4',
        datasourceBehavior: PV.Extensibility.Enums.DatasourceBehaviors.Multiple,
        iconUrl: 'Scripts/app/editor/symbols/ext/icons/mm20.png',
        supportsCollections: true,
        visObjectType: symbolVis,
        getDefaultConfig: function () {
            return {
                DataShape: 'Table', Columns: ['Value'], Height: 800, Width: 1400,
                DataUpdateInterval: 30000,
                // General
                Title: '\u05E0\u05D9\u05D8\u05D5\u05E8 \u05E9\u05E2\u05D5\u05EA \u05E2\u05D1\u05D5\u05D3\u05D4 \u2014 \u05D9\u05D7\u05D9\u05D3\u05D5\u05EA \u05D9\u05D9\u05E6\u05D5\u05E8',
                Subtitle: '',
                LogoUrl: '',
                Decimals: 1,
                UseThousandsSep: true,
                // Footer
                FooterText: '\u05E0\u05D5\u05D2\u05D4 \u2014 \u05DE\u05E0\u05D4\u05DC \u05DE\u05E2\u05E8\u05DB\u05EA \u05D4\u05D7\u05E9\u05DE\u05DC | MM20-INT v20.0.R1',
                ShowFooter: true,
                // Quota
                ShowQuota: true, WarnPct: 70, CritPct: 90, HighlightOverQuota: true,
                // Layout
                AutoCollapse: true,
                ActiveTab: 'realtime',
                // Font
                fontFamily: 'Segoe UI', fontSize: 12, headerFontSize: 16,
                fontBold: false, fontItalic: false,
                // Reports
                ReportTemplate: 'monthly', ReportGrouping: 'site',
                SavedTemplates: [],
                // Alerts
                AlertQuotaPct: 90, AlertHoursMax: 1000, AlertStaleSec: 300,
                AlertSoundEnabled: false,
                // Per-unit overrides
                UnitSettings: {},
                // AF
                AFBasePath: '',
                StaleThreshold: 300,
                // TTE
                TTEEnabled: true, TTEHorizonDays: 30,
                // Sensitivity
                SensitivityEnabled: true,
                // Exception mode
                ExceptionMode: false,
                // Auto-refresh
                RefreshInterval: 30,
                EnableAutoRefresh: true,
                // System logging
                EnableSystemLog: true,
                MaxLogEntries: 500,
                // Demo mode
                DemoMode: false,
                // Custom sites
                CustomSites: [],
                SiteSettings: {},
                // Theme colors
                gradientStart: '#060C18',
                gradientEnd: '#0D1F35',
                cardBg: '#0F2940',
                accentColor: '#5BC0EB',
                okColor: '#2ECC71',
                warnColor: '#F39C12',
                critColor: '#E74C3C',
                // Limits
                limitHoursDaily: 0,
                limitHoursMonthly: 0,
                // Sort
                SortOrder: 'name',
                // R50: Favorites
                Favorites: {},
                FavoritesEnabled: true,
                // R51: Global search
                ShowGlobalSearch: false,
                // R52: Sparklines
                ShowSparklines: true,
                SparklinesEnabled: true,
                // R53: Annotations
                Annotations: {},
                // R54: Heatmap
                HeatmapSite: '',
                HeatmapMetric: 'hours',
                // R55: Push notifications
                PushNotificationsEnabled: false
            };
        },
        configTitle: '\u05E0\u05D9\u05D8\u05D5\u05E8 \u05DE\u05D5\u05D2\u05D1\u05DC\u05D5\u05EA v20-INT',
        configOptions: function () { return [{ title: 'Format Symbol', mode: 'format' }]; },
        // [FIX-JS-1] CRITICAL — inject array required for $interval/$timeout DI
        inject: ['$interval', '$timeout']
    };

    PV.symbolCatalog.register(def);

})(window.PIVisualization);
