var apiconfig = {
  servername: 'https://piwebapiserver/piwebapi',
};

var defaultTagColors = [
  '#5470c6',
  '#91cc75',
  '#fac858',
  '#ee6666',
  '#73c0de',
  '#3ba272',
  '#fc8452',
  '#9a60b4',
  '#ea7ccc',
  '#6e4318',
];

var weruSeeqIntegration = {
  seeqServerUrl: 'https://company.seeq.site',
  authProviderId: 'Seeq',
  authProviderClass: 'Auth',
  seeqUser: '',
  seeqPassword: '',
};

var HAconfig = {
  ActivateServerWatchdog: false,
  PIVisionServer1: '',
  PIVisionServer2: '',
  MaxTimeout: 5,
  Intervall: 1000,

  ActivatePIWatchdog: true,
  PIServer: 'piserver',
  PITag: 'sys.HealthTag.5sec',
  MaxSkippedUpdates: 3,
  WarnOffset: 1,
  PITimeOut: 15,

  ActivateStaticRefresh: false,
  RefreshIntervall: 3600,
};

var weruTimePicker = {
  yearButtonCount: 10,
  customButtons: [
    [
      //["Last 1 Day",'*-1d','*'],
      //["Last 2 Days",'*-2d','*']
      //['Past 12 months, excluding the current ongoing month', '01-1s', '01-1y'],
    ],
    [
      //["Easter 2022",'2023-04-15T00:00:00Z','2023-04-18T00:00:00Z'],
      //["Christmas 2022",'2023-12-24T00:00:00Z','2023-12-27T00:00:00Z']
    ],
    [
      //["timeSinceFirstAug",'2023-08-01T00:00:00Z','*']
    ],
  ],
};

var SankeyData = {
  links: [
    { target: 'Energy Generation', value: 100.0 },
    { source: 'Energy Generation', target: 'Engine 1', value: 60.5 },
    { source: 'Energy Generation', target: 'Engine 2', value: 34.5 },
    // {source: "Energy Generation", target: "Loss", value: "\\\\piserver\\pitag"},
    // {source: "Engine 1", target: "Engine 1 heat", value: "AFDatabase\\AFElement|Attribute"},
    // {source: "Engine 2", target: "Engine 2 heat", value: "8.42"}
  ],
};

var UNCFilePrograms = {
  docx: 'ms-word',
  doc: 'ms-word',
  xlsm: 'ms-excel',
  xlsx: 'ms-excel',
  txt: 'ms-word',
};

var werusysPVSSideBar = {
  headerLogoWidth: '100%',
  ticketPortal: '',
};

var weruNavigationMenu = {
  DefaultColors: {
    PrimaryColor: '#ffffff', //PrimaryColor
    PrimaryHoverColor: '#2282bf', //Top elements hover color
    HighlightColor: '#cdd0db', // Used to be part of PrimaryColor
    BorderColor: '#2282bf', //Used to be part of AccentColor
    SecondaryColor: '#ffffff', //Dropdown color
    SecondaryHoverColor: '#2282bf', //Used to be part of SecondaryColor
    TextColor: '#000000', //All text color
    PrimaryTextHoverColor: '#FFFFFF', //Used to be part of TextColor
    SecondaryTextHoverColor: '#FFFFFF', //Text hover for all dropdown elements
  },
  disableTemplateCheck: true,
};

var weruMapConfig = {

};

var DisableSymbols = {
  disable: [
    // {user: "Domain\\firstName.lastName", symbols: ["weruStackedBar", "weruSeeqAdHocAnalyzer"]},
    // {user: "Domain\\*", symbols: ["weruUNC"]},
  ],
  enable: [
    // {user: "Domain\\firstName.lastName", symbols: ["timeline2"]},
    // {user: "Domain\\*", symbols: ["weruUNC"]},
  ],
  disableIcons: true,
  disableSymbolSwitching: true,
  disableSymbolInstances: true,
};
var weruWatermark = {
  GxPCriteria: {
    DisplayNames: [],
    PathNames: [],
    DisplayIDS: [],
  },
  Indicators: {
    Icon: true,
    Text: true,
  },
};
var weruAudioWarn = {
  audioFiles: {
    //Displayname : Path
    '/PIVision/Scripts/app/editor/symbols/ext/sounds/warning_1.mp3': 'Warning 1',
  },
  loggingTag: '\\\\piserver\\loggingTag',
};
var weruStaleChecker = {
  NumOfSamples: 30,
  NumToRemove: 10,
  Factor: 3,
  UpdateIntervalSec: 10,
};
var weruExportTool = {
  maxCount: 150000,
}