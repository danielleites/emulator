/**
 * ═══════════════════════════════════════════════════════
 *  mm20-reports.js  —  Reports Tab Widget
 * ═══════════════════════════════════════════════════════
 *  Report generator: template selector, HTML preview,
 *  PDF via window.print(), CSV export.
 *
 *  jQuery widget: mm20.reports
 *  Version: 20.0.R1  |  ES5 only
 * ═══════════════════════════════════════════════════════
 */
(function ($) {
    'use strict';

    if (!$ || !$.widget) return;
    var MM = window.MM20;
    if (!MM) { console.error('[mm20-reports] MM20 core not loaded'); return; }

    $.widget('mm20.mm20Reports', {

        options: {
            bus:      null,
            sites:    null,
            data:     null,
            demoMode: false,
            template: 'monthly',
            grouping: 'site'
        },

        _destroyed: false,

        // ═══════════════════════════════════════
        //  _create
        // ═══════════════════════════════════════

        _create: function () {
            var self = this;
            self._destroyed = false;

            try {
                var el = self.element;
                el.addClass('mm20-reports-root');

                // ── Layout: sidebar + preview ──
                var panel = $('<div class="mm20-report-panel"></div>');

                // Sidebar
                var sidebar = $('<div class="mm20-report-sidebar"></div>');
                sidebar.append($('<div style="font-weight:600; margin-bottom:8px;">\u05EA\u05D1\u05E0\u05D9\u05EA \u05D3\u05D5\u05D7</div>'));

                // Template buttons
                var templates = MM.REPORT_TEMPLATES || [];
                self._templateBtns = {};
                for (var i = 0; i < templates.length; i++) {
                    (function (tmpl) {
                        var btn = $('<button class="mm20-report-btn"></button>').text(tmpl.name);
                        if (self.options.template === tmpl.id) btn.addClass('mm20-report-btn--active');
                        btn.on('click', function () {
                            self.options.template = tmpl.id;
                            self._updateTemplateBtns();
                            self._generatePreview();
                        });
                        self._templateBtns[tmpl.id] = btn;
                        sidebar.append(btn);
                    })(templates[i]);
                }

                // Grouping selector
                sidebar.append($('<div style="font-weight:600; margin-top:12px; margin-bottom:4px;">\u05E7\u05D9\u05D1\u05D5\u05E5</div>'));
                self._groupSelect = $('<select class="mm20-hm-select" style="width:100%;"></select>');
                var groups = MM.GROUPING_OPTIONS || [];
                for (var g = 0; g < groups.length; g++) {
                    self._groupSelect.append($('<option></option>').val(groups[g].id).text(groups[g].name));
                }
                self._groupSelect.val(self.options.grouping);
                self._groupSelect.on('change', function () {
                    self.options.grouping = this.value;
                    self._generatePreview();
                });
                sidebar.append(self._groupSelect);

                // Action buttons
                sidebar.append($('<div style="margin-top:12px;"></div>'));

                var genBtn = $('<button class="mm20-report-btn" style="background:var(--mm20-accent,#5BC0EB); color:#000; font-weight:600;">\u05D9\u05E6\u05E8 \u05D3\u05D5\u05D7</button>');
                genBtn.on('click', function () { self._generatePreview(); });
                sidebar.append(genBtn);

                var csvBtn = $('<button class="mm20-report-btn">\u05D9\u05E6\u05D5\u05D0 CSV</button>');
                csvBtn.on('click', function () { self._exportCsv(); });
                sidebar.append(csvBtn);

                var pdfBtn = $('<button class="mm20-report-btn">\u05D9\u05E6\u05D5\u05D0 PDF</button>');
                pdfBtn.on('click', function () { self._exportPdf(); });
                sidebar.append(pdfBtn);

                panel.append(sidebar);

                // Preview area
                self._previewEl = $('<div class="mm20-report-preview"></div>');
                self._previewEl.html('<div class="mm20-tags-placeholder">\u05D1\u05D7\u05E8 \u05EA\u05D1\u05E0\u05D9\u05EA \u05D5\u05DC\u05D7\u05E5 "\u05D9\u05E6\u05E8 \u05D3\u05D5\u05D7"</div>');
                panel.append(self._previewEl);

                el.append(panel);

            } catch (e) {
                MM.shield.log('reports', '_create', e);
                MM.shield.renderFallback(self.element, 'reports', e);
            }
        },


        // ─────────────────────────────────────
        //  Generate report preview
        // ─────────────────────────────────────

        _generatePreview: function () {
            var self = this;
            var sites = self.options.sites || MM.SITES;
            var data = self.options.data;

            if (!data && self.options.demoMode) {
                data = MM.demo.generateSites(sites);
            }
            if (!data) {
                self._previewEl.html('<div class="mm20-tags-placeholder">\u05D0\u05D9\u05DF \u05E0\u05EA\u05D5\u05E0\u05D9\u05DD \u05DC\u05D3\u05D5\u05D7</div>');
                return;
            }

            var cols = MM.REPORT_COLS || [];
            var grouping = self.options.grouping;
            var now = MM.formatDate(new Date());

            // Build report rows
            var rows = self._buildRows(sites, data);

            // Group rows
            if (grouping !== 'site') {
                rows = self._groupRows(rows, grouping);
            }

            // Build HTML table
            var html = '<div dir="rtl" style="font-family:inherit;">';
            html += '<h3 style="margin:0 0 8px;">\u05D3\u05D5\u05D7 ' + self._getTemplateName() + '</h3>';
            html += '<p style="font-size:10px; color:#8899AA;">\u05E0\u05D5\u05E6\u05E8: ' + now + '</p>';
            html += '<table class="mm20-log-table" style="width:100%;">';
            html += '<thead><tr>';
            for (var c = 0; c < cols.length; c++) {
                if (cols[c].def) {
                    html += '<th>' + MM.escapeHtml(cols[c].label) + '</th>';
                }
            }
            html += '</tr></thead><tbody>';

            for (var r = 0; r < rows.length; r++) {
                html += '<tr>';
                for (var cc = 0; cc < cols.length; cc++) {
                    if (cols[cc].def) {
                        var val = rows[r][cols[cc].id];
                        html += '<td>' + MM.escapeHtml(val !== undefined ? val : '--') + '</td>';
                    }
                }
                html += '</tr>';
            }

            html += '</tbody></table></div>';
            self._previewEl.html(html);

            // Store for export
            self._reportRows = rows;
        },

        _buildRows: function (sites, data) {
            var rows = [];
            for (var s = 0; s < sites.length; s++) {
                var site = sites[s];
                var siteData = data[site.id];
                if (!siteData) continue;

                for (var u = 0; u < site.units.length; u++) {
                    var ud = siteData[u];
                    rows.push({
                        site:   site.name,
                        unit:   site.units[u],
                        status: ud ? (MM.STATUS_LABELS[ud.status] || ud.status || '--') : '--',
                        hours:  ud ? MM.formatNum(ud.hours, 0) : '--',
                        quota:  ud ? MM.formatNum(ud.quota, 0) : '--',
                        pct:    ud ? MM.formatNum(ud.pct, 1) + '%' : '--',
                        fuel:   site.fuel,
                        region: site.region
                    });
                }
            }
            return rows;
        },

        _groupRows: function (rows, grouping) {
            // Sort rows by grouping key
            rows.sort(function (a, b) {
                var ka = a[grouping] || '';
                var kb = b[grouping] || '';
                return ka.localeCompare(kb);
            });
            return rows;
        },

        _getTemplateName: function () {
            var templates = MM.REPORT_TEMPLATES || [];
            for (var i = 0; i < templates.length; i++) {
                if (templates[i].id === this.options.template) return templates[i].name;
            }
            return this.options.template;
        },


        // ─────────────────────────────────────
        //  Update template buttons
        // ─────────────────────────────────────

        _updateTemplateBtns: function () {
            var active = this.options.template;
            for (var key in this._templateBtns) {
                if (this._templateBtns.hasOwnProperty(key)) {
                    this._templateBtns[key].toggleClass('mm20-report-btn--active', key === active);
                }
            }
        },


        // ─────────────────────────────────────
        //  Export CSV
        // ─────────────────────────────────────

        _exportCsv: function () {
            if (!this._reportRows || !this._reportRows.length) {
                this._generatePreview();
            }
            if (this._reportRows) {
                MM.exportCsv(this._reportRows, 'mm20-report-' + MM.formatDate(new Date(), 'date').replace(/\//g, '-') + '.csv');
            }
        },


        // ─────────────────────────────────────
        //  Export PDF (via print dialog)
        // ─────────────────────────────────────

        _exportPdf: function () {
            if (!this._previewEl) return;

            // Open print-friendly window with report content
            var printWin = window.open('', '_blank', 'width=800,height=600');
            if (!printWin) return;

            var content = this._previewEl.html();
            printWin.document.write(
                '<!DOCTYPE html><html dir="rtl"><head><meta charset="UTF-8">' +
                '<title>\u05D3\u05D5\u05D7 \u05DE\u05D5\u05D2\u05D1\u05DC\u05D5\u05EA</title>' +
                '<style>' +
                'body { font-family: "Segoe UI", Arial, sans-serif; font-size: 12px; direction: rtl; padding: 20px; }' +
                'table { width: 100%; border-collapse: collapse; }' +
                'th, td { border: 1px solid #ccc; padding: 4px 8px; text-align: right; }' +
                'th { background: #f0f0f0; font-weight: 600; }' +
                '</style></head><body>' + content + '</body></html>'
            );
            printWin.document.close();
            printWin.focus();
            setTimeout(function () { printWin.print(); }, 300);
        },


        // ═══════════════════════════════════════
        //  _setOption
        // ═══════════════════════════════════════

        _setOption: function (key, value) {
            this._super(key, value);

            if (key === 'data') {
                // Data updated — don't auto-regenerate preview, user clicks "generate"
            } else if (key === 'template') {
                this._updateTemplateBtns();
            }
        },


        // ═══════════════════════════════════════
        //  _destroy
        // ═══════════════════════════════════════

        _destroy: function () {
            this._destroyed = true;
            this._reportRows = null;
            this.element.empty().removeClass('mm20-reports-root');
        }
    });

})(window.jQuery);
