/**
 * ═══════════════════════════════════════════════════════
 *  MM20-CORE  —  Mugbalot Monitor v20 Infrastructure
 * ═══════════════════════════════════════════════════════
 *  Signal bus · Error shield · Stats · Demo engine
 *  SITES array · Utility functions
 *
 *  Version : 20.0.R1
 *  ES5 only — IE11 compatible
 *  Loaded FIRST via <script> in template; all widgets
 *  depend on window.MM20 namespace.
 * ═══════════════════════════════════════════════════════
 */
(function (root) {
    'use strict';

    // Prevent double-init
    if (root.MM20 && root.MM20._loaded) return;

    var MM20 = root.MM20 = {};
    MM20._loaded = true;
    MM20.VERSION = '20.0.R1';


    // ═══════════════════════════════════════
    //  1. SIGNAL BUS  (per-instance factory)
    // ═══════════════════════════════════════

    /**
     * Creates a fresh, isolated pub/sub bus.
     * Each symbol instance gets its own bus so events
     * never leak between multiple monitors on one display.
     *
     * @returns {{ on, off, emit, once, reset }}
     */
    MM20.createBus = function () {
        var _channels = {};

        return {
            /**
             * Subscribe to a channel.
             * @param {string} channel
             * @param {Function} fn
             * @param {Object} [ctx] - optional `this` context
             */
            on: function (channel, fn, ctx) {
                if (!_channels[channel]) _channels[channel] = [];
                _channels[channel].push({ fn: fn, ctx: ctx || null });
            },

            /**
             * Unsubscribe a specific handler from a channel.
             */
            off: function (channel, fn) {
                var subs = _channels[channel];
                if (!subs) return;
                for (var i = subs.length - 1; i >= 0; i--) {
                    if (subs[i].fn === fn) subs.splice(i, 1);
                }
            },

            /**
             * Publish data to all subscribers on a channel.
             * Each handler is error-shielded — a throwing subscriber
             * never breaks other subscribers.
             */
            emit: function (channel, data) {
                var subs = _channels[channel];
                if (!subs) return;
                for (var i = 0; i < subs.length; i++) {
                    try {
                        subs[i].fn.call(subs[i].ctx, data);
                    } catch (e) {
                        MM20.shield.log('bus:' + channel, 'emit', e);
                    }
                }
            },

            /**
             * Subscribe once — auto-removes after first call.
             */
            once: function (channel, fn, ctx) {
                var self = this;
                var wrapper = function (data) {
                    self.off(channel, wrapper);
                    fn.call(ctx || null, data);
                };
                this.on(channel, wrapper, ctx);
            },

            /**
             * Drop all subscriptions (called on $destroy).
             */
            reset: function () {
                _channels = {};
            }
        };
    };


    // ═══════════════════════════════════════
    //  2. ERROR SHIELD
    // ═══════════════════════════════════════

    MM20.shield = (function () {
        var _errors = [];
        var MAX = 200;

        return {
            /**
             * Wrap a function in try/catch. Returns a safe version.
             * @param {string} source  - widget name (e.g. 'siteGrid')
             * @param {string} fnName  - method name (e.g. 'dataUpdate')
             * @param {Function} fn
             * @returns {Function}
             */
            wrap: function (source, fnName, fn) {
                var self = this;
                return function () {
                    try {
                        return fn.apply(this, arguments);
                    } catch (e) {
                        self.log(source, fnName, e);
                        return undefined;
                    }
                };
            },

            /**
             * Record an error.
             */
            log: function (source, fnName, error) {
                var entry = {
                    ts: new Date().toISOString(),
                    source: source,
                    fn: fnName,
                    msg: (error && error.message) ? error.message : String(error),
                    stack: (error && error.stack) ? error.stack : ''
                };
                _errors.push(entry);
                if (_errors.length > MAX) _errors.shift();

                // Console output for developers
                if (typeof console !== 'undefined' && console.error) {
                    console.error('[MM20][' + source + '.' + fnName + ']', error);
                }
            },

            /**
             * Get all collected errors (copy).
             */
            getErrors: function () {
                return _errors.slice();
            },

            /**
             * Clear error log.
             */
            clear: function () {
                _errors.length = 0;
            },

            /**
             * Render an inline error fallback inside a container element.
             * @param {jQuery|HTMLElement} el
             * @param {string} widgetName
             * @param {Error} err
             */
            renderFallback: function (el, widgetName, err) {
                var html =
                    '<div class="mm20-error-fallback" dir="rtl">' +
                        '<span>\u26A0 \u05E9\u05D2\u05D9\u05D0\u05D4 \u05D1\u05D8\u05E2\u05D9\u05E0\u05EA ' + MM20.escapeHtml(widgetName) + '</span>' +
                        '<br><small>' + MM20.escapeHtml((err && err.message) || '') + '</small>' +
                    '</div>';
                if (el.html) { el.html(html); } else { el.innerHTML = html; }
            }
        };
    })();


    // ═══════════════════════════════════════
    //  3. STATS HELPERS
    // ═══════════════════════════════════════

    MM20.stats = {
        min: function (arr) {
            if (!arr || !arr.length) return 0;
            var m = arr[0];
            for (var i = 1; i < arr.length; i++) { if (arr[i] < m) m = arr[i]; }
            return m;
        },
        max: function (arr) {
            if (!arr || !arr.length) return 0;
            var m = arr[0];
            for (var i = 1; i < arr.length; i++) { if (arr[i] > m) m = arr[i]; }
            return m;
        },
        sum: function (arr) {
            var s = 0;
            for (var i = 0; arr && i < arr.length; i++) s += (arr[i] || 0);
            return s;
        },
        avg: function (arr) {
            return (arr && arr.length) ? this.sum(arr) / arr.length : 0;
        },
        /**
         * Rate of change per hour.
         * @param {number} prev - previous value
         * @param {number} curr - current value
         * @param {number} dtMs - elapsed milliseconds
         */
        rateOfChange: function (prev, curr, dtMs) {
            if (!dtMs || dtMs <= 0) return 0;
            return ((curr - prev) / dtMs) * 3600000; // per hour
        },
        /**
         * Simple linear forecast.
         * @param {number} current  - current value
         * @param {number} rate     - rate per hour
         * @param {number} target   - target value
         * @returns {number} hours until target, or Infinity
         */
        forecast: function (current, rate, target) {
            if (rate <= 0) return Infinity;
            var remaining = target - current;
            if (remaining <= 0) return 0;
            return remaining / rate;
        }
    };


    // ═══════════════════════════════════════
    //  4. DEFAULT SITES  (15 plants, 37 units)
    // ═══════════════════════════════════════

    MM20.SITES = [
        { id: 'orot',       name: '\u05D0\u05D5\u05E8\u05D5\u05EA \u05E8\u05D1\u05D9\u05DF',           region: '\u05DE\u05E8\u05DB\u05D6', fuel: '\u05E4\u05D7\u05DD',       units: ['\u05D0\u05D5\u05E8\u05D5\u05EA \u05E8\u05D1\u05D9\u05DF 1', '\u05D0\u05D5\u05E8\u05D5\u05EA \u05E8\u05D1\u05D9\u05DF 2', '\u05D0\u05D5\u05E8\u05D5\u05EA \u05E8\u05D1\u05D9\u05DF 3', '\u05D0\u05D5\u05E8\u05D5\u05EA \u05E8\u05D1\u05D9\u05DF 4', '\u05D0\u05D5\u05E8\u05D5\u05EA \u05E8\u05D1\u05D9\u05DF 5', '\u05D0\u05D5\u05E8\u05D5\u05EA \u05E8\u05D1\u05D9\u05DF 6', '\u05E1\u05D9\u05DC\u05D5\u05E0\u05D9\u05EA'] },
        { id: 'rtnb',       name: '\u05E8\u05D5\u05D8\u05E0\u05D1\u05E8\u05D2',                       region: '\u05D3\u05E8\u05D5\u05DD', fuel: '\u05D2\u05D6 \u05D8\u05D1\u05E2\u05D9', units: ['\u05E8\u05D5\u05D8\u05E0\u05D1\u05E8\u05D2 1', '\u05E8\u05D5\u05D8\u05E0\u05D1\u05E8\u05D2 2', '\u05E8\u05D5\u05D8\u05E0\u05D1\u05E8\u05D2 3', '\u05E8\u05D5\u05D8\u05E0\u05D1\u05E8\u05D2 4'] },
        { id: 'eilat',      name: '\u05D0\u05D9\u05DC\u05EA',                                         region: '\u05D3\u05E8\u05D5\u05DD', fuel: '\u05D3\u05D9\u05D6\u05DC',             units: ['\u05D0\u05D9\u05DC\u05EA 1', '\u05D0\u05D9\u05DC\u05EA 2', '\u05D0\u05D9\u05DC\u05EA 3'] },
        { id: 'eitan',      name: '\u05D0\u05D9\u05EA\u05DF',                                         region: '\u05DE\u05E8\u05DB\u05D6', fuel: '\u05D2\u05D6 \u05D8\u05D1\u05E2\u05D9', units: ['\u05D0\u05D9\u05EA\u05DF 1'] },
        { id: 'alon',       name: '\u05D0\u05DC\u05D5\u05DF \u05EA\u05D1\u05D5\u05E8',                 region: '\u05E6\u05E4\u05D5\u05DF', fuel: '\u05D2\u05D6 \u05D8\u05D1\u05E2\u05D9', units: ['\u05D9\u05D7 1', '\u05D9\u05D7 2', '\u05D9\u05D7 6', '\u05D9\u05D7 7'] },
        { id: 'eshkol',     name: '\u05D0\u05E9\u05DB\u05D5\u05DC',                                   region: '\u05D3\u05E8\u05D5\u05DD', fuel: '\u05D2\u05D6 \u05D8\u05D1\u05E2\u05D9', units: ['\u05D0\u05E9\u05DB\u05D5\u05DC 6', '\u05D0\u05E9\u05DB\u05D5\u05DC 7', '\u05D0\u05E9\u05DB\u05D5\u05DC 8', '\u05D0\u05E9\u05DB\u05D5\u05DC 9'] },
        { id: 'egel',       name: '\u05D0\u05EA\u05D2\u05DC',                                         region: '\u05DE\u05E8\u05DB\u05D6', fuel: '\u05D2\u05D6 \u05D8\u05D1\u05E2\u05D9', units: ['\u05D0\u05EA\u05D2\u05DC 1'] },
        { id: 'hartov',     name: '\u05D4\u05E8-\u05D8\u05D5\u05D1',                                   region: '\u05DE\u05E8\u05DB\u05D6', fuel: '\u05D2\u05D6 \u05D8\u05D1\u05E2\u05D9', units: ['\u05D4\u05E8-\u05D8\u05D5\u05D1 1'] },
        { id: 'hagit',      name: '\u05D7\u05D2\u05D9\u05EA',                                         region: '\u05E6\u05E4\u05D5\u05DF', fuel: '\u05D2\u05D6 \u05D8\u05D1\u05E2\u05D9', units: ['\u05D7\u05D2\u05D9\u05EA 1', '\u05D7\u05D2\u05D9\u05EA 2'] },
        { id: 'reading',    name: '\u05E8\u05D3\u05D9\u05E0\u05D2',                                   region: '\u05DE\u05E8\u05DB\u05D6', fuel: '\u05D2\u05D6 \u05D8\u05D1\u05E2\u05D9', units: ['\u05E8\u05D3\u05D9\u05E0\u05D2 1', '\u05E8\u05D3\u05D9\u05E0\u05D2 2'] },
        { id: 'gezer',      name: '\u05D2\u05D6\u05E8',                                               region: '\u05DE\u05E8\u05DB\u05D6', fuel: '\u05D2\u05D6 \u05D8\u05D1\u05E2\u05D9', units: ['\u05D2\u05D6\u05E8 1'] },
        { id: 'opc_rotem',  name: 'OPC \u05E8\u05D5\u05EA\u05DD',                                     region: '\u05D3\u05E8\u05D5\u05DD', fuel: '\u05D2\u05D6 \u05D8\u05D1\u05E2\u05D9', units: ['\u05E8\u05D5\u05EA\u05DD 1', '\u05E8\u05D5\u05EA\u05DD 2'] },
        { id: 'opc_hadera', name: 'OPC \u05D7\u05D3\u05E8\u05D4',                                     region: '\u05E6\u05E4\u05D5\u05DF', fuel: '\u05D2\u05D6 \u05D8\u05D1\u05E2\u05D9', units: ['\u05D7\u05D3\u05E8\u05D4 1'] },
        { id: 'dorad',      name: '\u05D3\u05D5\u05E8\u05D3',                                         region: '\u05D3\u05E8\u05D5\u05DD', fuel: '\u05D2\u05D6 \u05D8\u05D1\u05E2\u05D9', units: ['\u05D3\u05D5\u05E8\u05D3 1', '\u05D3\u05D5\u05E8\u05D3 2'] },
        { id: 'dalia',      name: '\u05D3\u05DC\u05D9\u05D4 \u05D0\u05E0\u05E8\u05D2\u05D9\u05D5\u05EA', region: '\u05E6\u05E4\u05D5\u05DF', fuel: '\u05D2\u05D6 \u05D8\u05D1\u05E2\u05D9', units: ['\u05D3\u05DC\u05D9\u05D4 1'] }
    ];

    // ── Status labels ──
    MM20.STATUS_LABELS = {
        critical: '\u05E7\u05E8\u05D9\u05D8\u05D9',
        warn:     '\u05D0\u05D6\u05D4\u05E8\u05D4',
        ok:       '\u05EA\u05E7\u05D9\u05DF',
        off:      '\u05DB\u05D1\u05D5\u05D9',
        standby:  '\u05D4\u05DE\u05EA\u05E0\u05D4',
        maintenance: '\u05EA\u05D7\u05D6\u05D5\u05E7\u05D4'
    };

    // ── Report templates ──
    MM20.REPORT_TEMPLATES = [
        { id: 'monthly',          name: '\u05D3\u05D5\u05D7 \u05D7\u05D5\u05D3\u05E9\u05D9' },
        { id: 'critical',         name: '\u05D9\u05D7\u05D9\u05D3\u05D5\u05EA \u05E7\u05E8\u05D9\u05D8\u05D9\u05D5\u05EA' },
        { id: 'annual',           name: '\u05D3\u05D5\u05D7 \u05E9\u05E0\u05EA\u05D9' },
        { id: 'guard',            name: '\u05DE\u05E9\u05DE\u05E8\u05D5\u05EA' },
        { id: 'custom',           name: '\u05DE\u05D5\u05EA\u05D0\u05DD \u05D0\u05D9\u05E9\u05D9\u05EA' },
        { id: 'monthlyBreakdown', name: '\u05E4\u05D9\u05E8\u05D5\u05D8 \u05D7\u05D5\u05D3\u05E9\u05D9' },
        { id: 'yoy',              name: '\u05D4\u05E9\u05D5\u05D5\u05D0\u05D4 \u05E9\u05E0\u05EA\u05D9\u05EA' }
    ];

    MM20.GROUPING_OPTIONS = [
        { id: 'site',   name: '\u05DC\u05E4\u05D9 \u05D0\u05EA\u05E8' },
        { id: 'status', name: '\u05DC\u05E4\u05D9 \u05E1\u05D8\u05D8\u05D5\u05E1' },
        { id: 'fuel',   name: '\u05DC\u05E4\u05D9 \u05D3\u05DC\u05E7' },
        { id: 'region', name: '\u05DC\u05E4\u05D9 \u05D0\u05D6\u05D5\u05E8' }
    ];

    MM20.MONTHS_HE = [
        '\u05D9\u05E0\u05D5\u05D0\u05E8', '\u05E4\u05D1\u05E8\u05D5\u05D0\u05E8', '\u05DE\u05E8\u05E5',
        '\u05D0\u05E4\u05E8\u05D9\u05DC', '\u05DE\u05D0\u05D9', '\u05D9\u05D5\u05E0\u05D9',
        '\u05D9\u05D5\u05DC\u05D9', '\u05D0\u05D5\u05D2\u05D5\u05E1\u05D8', '\u05E1\u05E4\u05D8\u05DE\u05D1\u05E8',
        '\u05D0\u05D5\u05E7\u05D8\u05D5\u05D1\u05E8', '\u05E0\u05D5\u05D1\u05DE\u05D1\u05E8', '\u05D3\u05E6\u05DE\u05D1\u05E8'
    ];

    // Report column definitions
    MM20.REPORT_COLS = [
        { id: 'site',    label: '\u05D0\u05EA\u05E8',              def: true  },
        { id: 'unit',    label: '\u05D9\u05D7\u05D9\u05D3\u05D4',  def: true  },
        { id: 'status',  label: '\u05E1\u05D8\u05D8\u05D5\u05E1',  def: true  },
        { id: 'hours',   label: '\u05E9\u05E2\u05D5\u05EA',        def: true  },
        { id: 'quota',   label: '\u05DE\u05DB\u05E1\u05D4',        def: true  },
        { id: 'pct',     label: '% \u05E0\u05D9\u05E6\u05D5\u05DC', def: true  },
        { id: 'fuel',    label: '\u05D3\u05DC\u05E7',              def: false },
        { id: 'region',  label: '\u05D0\u05D6\u05D5\u05E8',        def: false },
        { id: 'totalLY', label: '\u05E9\u05E0\u05D4 \u05E7\u05D5\u05D3\u05DE\u05EA', def: false },
        { id: 'diff',    label: '\u05D4\u05E4\u05E8\u05E9',        def: false },
        { id: 'diffPct', label: '\u05D4\u05E4\u05E8\u05E9 %',      def: false },
        { id: 'rate',    label: '\u05E7\u05E6\u05D1 \u05D9\u05D5\u05DE\u05D9', def: false },
        { id: 'monthly', label: '\u05D7\u05D5\u05D3\u05E9\u05D9\u05DD', def: false }
    ];


    // ═══════════════════════════════════════
    //  5. DEMO DATA ENGINE
    // ═══════════════════════════════════════

    MM20.demo = {
        /**
         * Generate fake realtime data for all sites/units.
         * @param {Array} siteDefs - MM20.SITES or cfg.CustomSites
         * @returns {Object} { siteId: { unitIdx: { hours, quota, pct, status, tte, ts } } }
         */
        generateSites: function (siteDefs) {
            var result = {};
            var now = new Date().toISOString();
            for (var s = 0; s < siteDefs.length; s++) {
                var site = siteDefs[s];
                result[site.id] = {};
                for (var u = 0; u < site.units.length; u++) {
                    var hours = Math.round(Math.random() * 4000);
                    var quota = 1000 + Math.round(Math.random() * 3000);
                    var pct   = Math.round((hours / quota) * 1000) / 10;
                    var status = pct >= 90 ? 'critical' : pct >= 70 ? 'warn' : 'ok';
                    var tte = MM20.stats.forecast(hours, 0.5 + Math.random() * 2, quota);
                    result[site.id][u] = {
                        hours:  hours,
                        quota:  quota,
                        pct:    pct,
                        status: status,
                        tte:    Math.round(tte),
                        ts:     now,
                        monthly: MM20.demo._fakeMonthly()
                    };
                }
            }
            return result;
        },

        /**
         * Generate 12 months of fake monthly data for heatmap.
         * @returns {Array} [ { month: 0..11, value: number } ]
         */
        _fakeMonthly: function () {
            var arr = [];
            for (var m = 0; m < 12; m++) {
                arr.push({
                    month: m,
                    value: Math.round(Math.random() * 400)
                });
            }
            return arr;
        },

        /**
         * Generate demo history for heatmap (all sites × 12 months).
         * @param {Array} siteDefs
         * @param {number} months
         * @returns {Object} { siteId: { unitIdx: [ {month, value} ] } }
         */
        generateHistory: function (siteDefs, months) {
            var result = {};
            months = months || 12;
            for (var s = 0; s < siteDefs.length; s++) {
                var site = siteDefs[s];
                result[site.id] = {};
                for (var u = 0; u < site.units.length; u++) {
                    var arr = [];
                    for (var m = 0; m < months; m++) {
                        arr.push({ month: m, value: Math.round(Math.random() * 500) });
                    }
                    result[site.id][u] = arr;
                }
            }
            return result;
        }
    };


    // ═══════════════════════════════════════
    //  6. UTILITY FUNCTIONS
    // ═══════════════════════════════════════

    /**
     * Escape HTML entities for safe insertion.
     */
    MM20.escapeHtml = function (str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    };

    /**
     * Format a number with thousands separator and decimal places.
     * @param {number} val
     * @param {number} [decimals=1]
     * @param {boolean} [useSep=true]
     */
    MM20.formatNum = function (val, decimals, useSep) {
        if (val === null || val === undefined || isNaN(val)) return '--';
        decimals = (decimals !== undefined) ? decimals : 1;
        useSep = (useSep !== undefined) ? useSep : true;
        var fixed = Number(val).toFixed(decimals);
        if (!useSep) return fixed;
        var parts = fixed.split('.');
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        return parts.join('.');
    };

    /**
     * Format a Date to locale-friendly string.
     * @param {Date|string} dt
     * @param {string} [fmt] - 'date', 'time', or 'full' (default)
     */
    MM20.formatDate = function (dt, fmt) {
        if (!dt) return '--';
        var d = (dt instanceof Date) ? dt : new Date(dt);
        if (isNaN(d.getTime())) return '--';
        var pad = function (n) { return n < 10 ? '0' + n : '' + n; };
        var day  = pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + '/' + d.getFullYear();
        var time = pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
        if (fmt === 'date') return day;
        if (fmt === 'time') return time;
        return day + ' ' + time;
    };

    /**
     * Export an array of objects as CSV and trigger download.
     * @param {Array} rows - array of objects
     * @param {string} filename
     */
    MM20.exportCsv = function (rows, filename) {
        if (!rows || !rows.length) return;
        var keys = Object.keys(rows[0]);
        // BOM for Hebrew support in Excel
        var csv = '\uFEFF' + keys.join(',') + '\n';
        for (var i = 0; i < rows.length; i++) {
            var line = [];
            for (var k = 0; k < keys.length; k++) {
                var val = rows[i][keys[k]];
                if (val === null || val === undefined) val = '';
                val = String(val).replace(/"/g, '""');
                line.push('"' + val + '"');
            }
            csv += line.join(',') + '\n';
        }
        var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = filename || 'export.csv';
        a.style.display = 'none';
        document.body.appendChild(a);
        a.click();
        setTimeout(function () {
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }, 100);
    };

    /**
     * Get total unit count from a sites array.
     */
    MM20.totalUnits = function (sites) {
        var n = 0;
        for (var i = 0; i < sites.length; i++) n += sites[i].units.length;
        return n;
    };

    /**
     * Determine quota status from percentage and thresholds.
     * @param {number} pct
     * @param {number} warn - default 70
     * @param {number} crit - default 90
     * @returns {string} 'ok' | 'warn' | 'critical'
     */
    MM20.getStatus = function (pct, warn, crit) {
        warn = warn || 70;
        crit = crit || 90;
        if (pct >= crit) return 'critical';
        if (pct >= warn) return 'warn';
        return 'ok';
    };

    /**
     * Build a unique key for a unit: siteId + '_' + unitIndex.
     */
    MM20.unitKey = function (siteId, unitIdx) {
        return siteId + '_' + unitIdx;
    };

    /**
     * Apply CSS custom properties from config theme values.
     * @param {HTMLElement} root - the symbol root element
     * @param {Object} cfg - scope.config
     */
    MM20.applyTheme = function (root, cfg) {
        if (!root || !root.style || !root.style.setProperty) return; // IE11 guard
        var map = {
            '--mm20-gradient-start': cfg.gradientStart,
            '--mm20-gradient-end':   cfg.gradientEnd,
            '--mm20-card-bg':        cfg.cardBg,
            '--mm20-accent':         cfg.accentColor,
            '--mm20-ok':             cfg.okColor,
            '--mm20-warn':           cfg.warnColor,
            '--mm20-crit':           cfg.critColor,
            '--mm20-font-family':    cfg.fontFamily,
            '--mm20-font-size':      (cfg.fontSize || 12) + 'px',
            '--mm20-header-size':    (cfg.headerFontSize || 16) + 'px'
        };
        for (var prop in map) {
            if (map.hasOwnProperty(prop) && map[prop] !== undefined) {
                try { root.style.setProperty(prop, map[prop]); } catch (e) { /* IE11 */ }
            }
        }
    };

})(window);
