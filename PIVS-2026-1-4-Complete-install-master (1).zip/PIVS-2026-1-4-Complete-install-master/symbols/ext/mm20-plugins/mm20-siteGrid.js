/**
 * ═══════════════════════════════════════════════════════
 *  mm20-siteGrid.js  —  Realtime Tab Widget
 * ═══════════════════════════════════════════════════════
 *  Site cards, unit rows, quota bars, TTE badges,
 *  sparklines, favorites, sort, filter, global search.
 *
 *  jQuery widget: mm20.siteGrid
 *  Version: 20.0.R1  |  ES5 only
 * ═══════════════════════════════════════════════════════
 */
(function ($) {
    'use strict';

    if (!$ || !$.widget) return;
    var MM = window.MM20;
    if (!MM) { console.error('[mm20-siteGrid] MM20 core not loaded'); return; }

    $.widget('mm20.mm20SiteGrid', {

        options: {
            bus:            null,
            sites:          null,
            data:           null,
            demoMode:       false,
            favorites:      {},
            sortOrder:      'name',
            warnPct:        70,
            critPct:        90,
            showSparklines: true,
            decimals:       1,
            annotations:    {},
            filterText:     ''
        },

        // ── DOM References (created once) ──
        _els: null,        // { siteId: { card, header, body, units: { idx: {row, name, bar, fill, label, tte, fav, spark} } } }
        _toolbarEl: null,
        _searchInput: null,
        _sortBtns: null,
        _gsearchOverlay: null,
        _destroyed: false,

        // ═══════════════════════════════════════
        //  _create — Build entire DOM structure
        // ═══════════════════════════════════════

        _create: function () {
            var self = this;
            self._destroyed = false;

            try {
                var el = self.element;
                el.addClass('mm20-site-grid-root');
                self._els = {};

                // ── Toolbar: search + sort buttons ──
                var toolbar = $('<div class="mm20-toolbar"></div>');

                self._searchInput = $('<input class="mm20-search-input" type="text" placeholder="\u05D7\u05D9\u05E4\u05D5\u05E9 \u05D9\u05D7\u05D9\u05D3\u05D4..." dir="rtl" />');
                self._searchInput.on('input', function () {
                    self.options.filterText = this.value;
                    self._applyFilter();
                });
                toolbar.append(self._searchInput);

                // Sort buttons
                var sortDefs = [
                    { key: 'name',   label: '\u05E9\u05DD' },
                    { key: 'pct',    label: '% \u05E0\u05D9\u05E6\u05D5\u05DC' },
                    { key: 'hours',  label: '\u05E9\u05E2\u05D5\u05EA' },
                    { key: 'tte',    label: 'TTE' },
                    { key: 'status', label: '\u05E1\u05D8\u05D8\u05D5\u05E1' }
                ];
                self._sortBtns = {};
                for (var i = 0; i < sortDefs.length; i++) {
                    (function (sd) {
                        var btn = $('<button class="mm20-sort-btn"></button>').text(sd.label);
                        if (self.options.sortOrder === sd.key) btn.addClass('mm20-sort-btn--active');
                        btn.on('click', function () {
                            self.options.sortOrder = sd.key;
                            self._updateSortBtns();
                            self._sortAndRender();
                        });
                        self._sortBtns[sd.key] = btn;
                        toolbar.append(btn);
                    })(sortDefs[i]);
                }

                el.append(toolbar);
                self._toolbarEl = toolbar;

                // ── Site Cards Container ──
                self._cardsContainer = $('<div class="mm20-cards-container"></div>');
                el.append(self._cardsContainer);

                // Build site cards
                var sites = self.options.sites || MM.SITES;
                self._buildCards(sites);

                // ── Global Search Overlay (hidden) ──
                self._buildSearchOverlay();

                // ── Bus subscriptions ──
                var bus = self.options.bus;
                if (bus) {
                    self._onSearchQuery = function (d) {
                        if (d.open) self._showSearch();
                        else self._hideSearch();
                    };
                    bus.on('search:query', self._onSearchQuery, self);

                    self._onDemoToggle = function (d) {
                        self.options.demoMode = d.enabled;
                    };
                    bus.on('demo:toggle', self._onDemoToggle, self);
                }

                // Seed demo data if needed
                if (self.options.demoMode && !self.options.data) {
                    self.options.data = MM.demo.generateSites(sites);
                    self._refreshData();
                }

            } catch (e) {
                MM.shield.log('siteGrid', '_create', e);
                MM.shield.renderFallback(self.element, 'siteGrid', e);
            }
        },


        // ─────────────────────────────────────
        //  Build site cards (DOM structure)
        // ─────────────────────────────────────

        _buildCards: function (sites) {
            var self = this;
            self._cardsContainer.empty();
            self._els = {};

            for (var s = 0; s < sites.length; s++) {
                var site = sites[s];
                var card = $('<div class="mm20-site-card" data-site="' + site.id + '"></div>');

                // Header
                var header = $('<div class="mm20-site-header"></div>');
                var nameSpan = $('<span class="mm20-site-name"></span>').text(site.name);
                var metaSpan = $('<span class="mm20-site-meta"></span>');
                metaSpan.append($('<span></span>').text(site.region));
                metaSpan.append($('<span></span>').text(site.fuel));
                metaSpan.append($('<span></span>').text(site.units.length + ' \u05D9\u05D7\u05D9\u05D3\u05D5\u05EA'));
                header.append(nameSpan).append(metaSpan);

                // Click to select site
                (function (sid, sname) {
                    header.on('click', function () {
                        if (self.options.bus) {
                            self.options.bus.emit('site:selected', { siteId: sid, siteName: sname });
                        }
                    });
                })(site.id, site.name);

                card.append(header);

                // Body (unit rows)
                var body = $('<div class="mm20-site-body"></div>');
                var unitEls = {};

                for (var u = 0; u < site.units.length; u++) {
                    var unitKey = MM.unitKey(site.id, u);
                    var row = $('<div class="mm20-unit-row" data-unit="' + unitKey + '"></div>');

                    // Favorite button
                    var favBtn = $('<button class="mm20-fav-btn" title="\u05DE\u05D5\u05E2\u05D3\u05E3">\u2606</button>');
                    if (self.options.favorites[unitKey]) favBtn.addClass('mm20-fav-btn--active').text('\u2605');
                    (function (key, btn) {
                        btn.on('click', function (e) {
                            e.stopPropagation();
                            self._toggleFavorite(key, btn);
                        });
                    })(unitKey, favBtn);

                    // Unit name
                    var uName = $('<span class="mm20-unit-name"></span>').text(site.units[u]);

                    // Quota bar
                    var barWrap = $('<div class="mm20-quota-bar-wrap"></div>');
                    var barFill = $('<div class="mm20-quota-bar-fill mm20-quota-bar-fill--ok"></div>').css('width', '0%');
                    var barLabel = $('<span class="mm20-quota-label"></span>').text('--');
                    barWrap.append(barFill).append(barLabel);

                    // TTE badge
                    var tteBadge = $('<span class="mm20-tte-badge"></span>').text('--');

                    // Sparkline SVG
                    var sparkSvg = null;
                    if (self.options.showSparklines) {
                        sparkSvg = $('<svg class="mm20-sparkline" viewBox="0 0 60 16" preserveAspectRatio="none"><polyline points=""></polyline></svg>');
                    }

                    // Annotation button
                    var annotBtn = $('<button class="mm20-annot-btn" title="\u05D4\u05E2\u05E8\u05D5\u05EA">\u270E</button>');
                    if (self.options.annotations[unitKey] && self.options.annotations[unitKey].length) {
                        annotBtn.addClass('mm20-annot-btn--has-notes');
                    }

                    // Assemble row
                    row.append(favBtn).append(uName).append(barWrap).append(tteBadge);
                    if (sparkSvg) row.append(sparkSvg);
                    row.append(annotBtn);

                    // Click to select unit
                    (function (sid, uidx, uname) {
                        row.on('click', function () {
                            if (self.options.bus) {
                                self.options.bus.emit('unit:selected', { siteId: sid, unitIdx: uidx, unitName: uname });
                            }
                        });
                    })(site.id, u, site.units[u]);

                    body.append(row);

                    unitEls[u] = {
                        row:    row,
                        name:   uName,
                        bar:    barWrap,
                        fill:   barFill,
                        label:  barLabel,
                        tte:    tteBadge,
                        fav:    favBtn,
                        spark:  sparkSvg,
                        annot:  annotBtn
                    };
                }

                card.append(body);
                self._cardsContainer.append(card);

                self._els[site.id] = {
                    card:   card,
                    header: header,
                    body:   body,
                    units:  unitEls
                };
            }
        },


        // ─────────────────────────────────────
        //  Data refresh (update DOM, don't rebuild)
        // ─────────────────────────────────────

        _refreshData: function () {
            var self = this;
            var data = self.options.data;
            if (!data) return;

            var sites = self.options.sites || MM.SITES;
            for (var s = 0; s < sites.length; s++) {
                var site = sites[s];
                var siteData = data[site.id];
                var siteEls = self._els[site.id];
                if (!siteEls) continue;

                for (var u = 0; u < site.units.length; u++) {
                    var uData = siteData ? siteData[u] : null;
                    var uEls = siteEls.units[u];
                    if (!uEls) continue;

                    if (!uData) {
                        uEls.fill.css('width', '0%')
                            .removeClass('mm20-quota-bar-fill--warn mm20-quota-bar-fill--critical')
                            .addClass('mm20-quota-bar-fill--ok');
                        uEls.label.text('--');
                        uEls.tte.text('--').removeClass('mm20-tte-badge--low');
                        continue;
                    }

                    // Quota bar
                    var pct = uData.pct || 0;
                    var clampedPct = Math.min(pct, 100);
                    uEls.fill.css('width', clampedPct + '%');
                    uEls.fill.removeClass('mm20-quota-bar-fill--ok mm20-quota-bar-fill--warn mm20-quota-bar-fill--critical');
                    var status = MM.getStatus(pct, self.options.warnPct, self.options.critPct);
                    uEls.fill.addClass('mm20-quota-bar-fill--' + status);

                    // Label
                    uEls.label.text(MM.formatNum(pct, self.options.decimals) + '%');

                    // TTE
                    if (uData.tte !== undefined && uData.tte !== Infinity) {
                        var tteHrs = Math.round(uData.tte);
                        uEls.tte.text(tteHrs + 'h');
                        if (tteHrs < 168) { // < 1 week
                            uEls.tte.addClass('mm20-tte-badge--low');
                        } else {
                            uEls.tte.removeClass('mm20-tte-badge--low');
                        }
                    } else {
                        uEls.tte.text('\u221E');
                        uEls.tte.removeClass('mm20-tte-badge--low');
                    }

                    // Sparkline
                    if (uEls.spark && uData.monthly && uData.monthly.length) {
                        self._renderSparkline(uEls.spark, uData.monthly);
                    }
                }
            }
        },


        // ─────────────────────────────────────
        //  Sparkline SVG polyline
        // ─────────────────────────────────────

        _renderSparkline: function (svgEl, monthly) {
            var points = [];
            var max = 1;
            for (var i = 0; i < monthly.length; i++) {
                if (monthly[i].value > max) max = monthly[i].value;
            }
            for (var j = 0; j < monthly.length; j++) {
                var x = Math.round((j / Math.max(monthly.length - 1, 1)) * 60);
                var y = Math.round(16 - (monthly[j].value / max) * 14);
                points.push(x + ',' + y);
            }
            var polyline = svgEl.find('polyline');
            if (polyline.length) {
                polyline.attr('points', points.join(' '));
            }
        },


        // ─────────────────────────────────────
        //  Favorites toggle
        // ─────────────────────────────────────

        _toggleFavorite: function (unitKey, btnEl) {
            var favs = this.options.favorites;
            if (favs[unitKey]) {
                delete favs[unitKey];
                btnEl.removeClass('mm20-fav-btn--active').text('\u2606');
            } else {
                favs[unitKey] = true;
                btnEl.addClass('mm20-fav-btn--active').text('\u2605');
            }
            if (this.options.bus) {
                this.options.bus.emit('favorites:changed', { favorites: favs });
            }
        },


        // ─────────────────────────────────────
        //  Sort
        // ─────────────────────────────────────

        _updateSortBtns: function () {
            var active = this.options.sortOrder;
            for (var key in this._sortBtns) {
                if (this._sortBtns.hasOwnProperty(key)) {
                    this._sortBtns[key].toggleClass('mm20-sort-btn--active', key === active);
                }
            }
        },

        _sortAndRender: function () {
            var self = this;
            var sites = self.options.sites || MM.SITES;
            var data = self.options.data || {};
            var order = self.options.sortOrder;

            // Build sortable list of site-level aggregates
            var sortable = [];
            for (var s = 0; s < sites.length; s++) {
                var site = sites[s];
                var siteData = data[site.id] || {};
                var avgPct = 0, totalHours = 0, minTte = Infinity, worstStatus = 0;
                var count = site.units.length;

                for (var u = 0; u < count; u++) {
                    var ud = siteData[u];
                    if (ud) {
                        avgPct += (ud.pct || 0);
                        totalHours += (ud.hours || 0);
                        if (ud.tte < minTte) minTte = ud.tte;
                        var sv = ud.status === 'critical' ? 2 : ud.status === 'warn' ? 1 : 0;
                        if (sv > worstStatus) worstStatus = sv;
                    }
                }
                avgPct = count > 0 ? avgPct / count : 0;

                sortable.push({
                    id: site.id, name: site.name,
                    avgPct: avgPct, totalHours: totalHours,
                    minTte: minTte, worstStatus: worstStatus
                });
            }

            // Sort
            sortable.sort(function (a, b) {
                switch (order) {
                    case 'pct':    return b.avgPct - a.avgPct;
                    case 'hours':  return b.totalHours - a.totalHours;
                    case 'tte':    return a.minTte - b.minTte;
                    case 'status': return b.worstStatus - a.worstStatus;
                    default:       return a.name.localeCompare(b.name);
                }
            });

            // Re-order DOM
            for (var i = 0; i < sortable.length; i++) {
                var el = self._els[sortable[i].id];
                if (el && el.card) {
                    self._cardsContainer.append(el.card);
                }
            }
        },


        // ─────────────────────────────────────
        //  Filter
        // ─────────────────────────────────────

        _applyFilter: function () {
            var term = (this.options.filterText || '').toLowerCase();
            var sites = this.options.sites || MM.SITES;

            for (var s = 0; s < sites.length; s++) {
                var site = sites[s];
                var siteEls = this._els[site.id];
                if (!siteEls) continue;

                var anyVisible = false;
                for (var u = 0; u < site.units.length; u++) {
                    var unitEl = siteEls.units[u];
                    if (!unitEl) continue;
                    var match = !term ||
                        site.name.toLowerCase().indexOf(term) >= 0 ||
                        site.units[u].toLowerCase().indexOf(term) >= 0 ||
                        site.id.toLowerCase().indexOf(term) >= 0;
                    unitEl.row.toggle(match);
                    if (match) anyVisible = true;
                }
                siteEls.card.toggle(anyVisible);
            }
        },


        // ─────────────────────────────────────
        //  Global Search Overlay
        // ─────────────────────────────────────

        _buildSearchOverlay: function () {
            var self = this;

            self._gsearchOverlay = $('<div class="mm20-gsearch-overlay" style="display:none;"></div>');
            var modal = $('<div class="mm20-gsearch-modal"></div>');
            self._gsearchInput = $('<input class="mm20-gsearch-input" type="text" placeholder="Ctrl+K \u05D7\u05D9\u05E4\u05D5\u05E9 \u05DE\u05D4\u05D9\u05E8..." dir="rtl" />');
            self._gsearchResults = $('<div class="mm20-gsearch-results"></div>');

            self._gsearchInput.on('input', function () {
                self._updateSearchResults(this.value);
            });

            self._gsearchInput.on('keydown', function (e) {
                if (e.keyCode === 27) { // Escape
                    self._hideSearch();
                } else if (e.keyCode === 13) { // Enter
                    var focused = self._gsearchResults.find('.mm20-gsearch-item--focused');
                    if (focused.length) focused.trigger('click');
                } else if (e.keyCode === 40) { // Arrow down
                    e.preventDefault();
                    self._moveSearchFocus(1);
                } else if (e.keyCode === 38) { // Arrow up
                    e.preventDefault();
                    self._moveSearchFocus(-1);
                }
            });

            // Close on overlay click
            self._gsearchOverlay.on('click', function (e) {
                if (e.target === self._gsearchOverlay[0]) self._hideSearch();
            });

            modal.append(self._gsearchInput).append(self._gsearchResults);
            self._gsearchOverlay.append(modal);
            self.element.append(self._gsearchOverlay);
        },

        _showSearch: function () {
            this._gsearchOverlay.show();
            this._gsearchInput.val('').focus();
            this._gsearchResults.empty();
        },

        _hideSearch: function () {
            this._gsearchOverlay.hide();
        },

        _updateSearchResults: function (term) {
            var self = this;
            var container = self._gsearchResults;
            container.empty();

            if (!term || term.length < 1) return;
            term = term.toLowerCase();

            var sites = self.options.sites || MM.SITES;
            var results = [];

            for (var s = 0; s < sites.length; s++) {
                var site = sites[s];
                for (var u = 0; u < site.units.length; u++) {
                    var unitName = site.units[u];
                    if (site.name.toLowerCase().indexOf(term) >= 0 ||
                        unitName.toLowerCase().indexOf(term) >= 0 ||
                        site.id.toLowerCase().indexOf(term) >= 0) {
                        results.push({ siteId: site.id, unitIdx: u, siteName: site.name, unitName: unitName });
                    }
                }
                if (results.length >= 20) break; // cap results
            }

            for (var r = 0; r < results.length; r++) {
                (function (res, idx) {
                    var item = $('<div class="mm20-gsearch-item"></div>')
                        .text(res.siteName + ' \u2014 ' + res.unitName);
                    if (idx === 0) item.addClass('mm20-gsearch-item--focused');
                    item.on('click', function () {
                        self._hideSearch();
                        // Scroll to the unit and highlight
                        var unitKey = MM.unitKey(res.siteId, res.unitIdx);
                        var siteEls = self._els[res.siteId];
                        if (siteEls && siteEls.units[res.unitIdx]) {
                            var row = siteEls.units[res.unitIdx].row;
                            siteEls.card.show();
                            row.show();
                            row[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
                            row.css('background', 'rgba(91,192,235,0.2)');
                            setTimeout(function () { row.css('background', ''); }, 2000);
                        }
                        if (self.options.bus) {
                            self.options.bus.emit('unit:selected', {
                                siteId: res.siteId, unitIdx: res.unitIdx, unitName: res.unitName
                            });
                        }
                    });
                    container.append(item);
                })(results[r], r);
            }
        },

        _moveSearchFocus: function (dir) {
            var items = this._gsearchResults.find('.mm20-gsearch-item');
            if (!items.length) return;
            var curr = items.filter('.mm20-gsearch-item--focused');
            var idx = items.index(curr);
            items.removeClass('mm20-gsearch-item--focused');
            var next = idx + dir;
            if (next < 0) next = items.length - 1;
            if (next >= items.length) next = 0;
            $(items[next]).addClass('mm20-gsearch-item--focused');
        },


        // ═══════════════════════════════════════
        //  _setOption — React to option changes
        // ═══════════════════════════════════════

        _setOption: function (key, value) {
            this._super(key, value);

            if (key === 'data') {
                this._refreshData();
            } else if (key === 'sortOrder') {
                this._updateSortBtns();
                this._sortAndRender();
            } else if (key === 'filterText') {
                this._applyFilter();
            } else if (key === 'sites') {
                this._buildCards(value || MM.SITES);
                this._refreshData();
            } else if (key === 'warnPct' || key === 'critPct') {
                this._refreshData();
            }
        },


        // ═══════════════════════════════════════
        //  _destroy — Cleanup
        // ═══════════════════════════════════════

        _destroy: function () {
            this._destroyed = true;

            // Unsubscribe bus
            var bus = this.options.bus;
            if (bus) {
                if (this._onSearchQuery) bus.off('search:query', this._onSearchQuery);
                if (this._onDemoToggle) bus.off('demo:toggle', this._onDemoToggle);
            }

            // Remove event listeners
            if (this._searchInput) this._searchInput.off();
            if (this._gsearchOverlay) this._gsearchOverlay.off();
            if (this._gsearchInput) this._gsearchInput.off();

            // Clear DOM refs
            this._els = null;
            this._sortBtns = null;
            this.element.empty().removeClass('mm20-site-grid-root');
        }
    });

})(window.jQuery);
