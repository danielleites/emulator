/**
 * ═══════════════════════════════════════════════════════
 *  mm20-heatmap.js  —  Heatmap Tab Widget
 * ═══════════════════════════════════════════════════════
 *  Monthly color-coded matrix (units × months),
 *  metric selector, color scale, tooltip.
 *
 *  jQuery widget: mm20.heatmap
 *  Version: 20.0.R1  |  ES5 only
 * ═══════════════════════════════════════════════════════
 */
(function ($) {
    'use strict';

    if (!$ || !$.widget) return;
    var MM = window.MM20;
    if (!MM) { console.error('[mm20-heatmap] MM20 core not loaded'); return; }

    $.widget('mm20.mm20Heatmap', {

        options: {
            bus:        null,
            sites:      null,
            data:       null,
            demoMode:   false,
            metric:     'hours',
            siteFilter: ''
        },

        _gridEl: null,
        _tooltipEl: null,
        _destroyed: false,

        // ═══════════════════════════════════════
        //  _create
        // ═══════════════════════════════════════

        _create: function () {
            var self = this;
            self._destroyed = false;

            try {
                var el = self.element;
                el.addClass('mm20-heatmap-root');

                // ── Controls ──
                var controls = $('<div class="mm20-hm-controls"></div>');

                controls.append($('<span>\u05DE\u05D3\u05D3:</span>'));
                self._metricSelect = $('<select class="mm20-hm-select"></select>');
                self._metricSelect.append('<option value="hours">\u05E9\u05E2\u05D5\u05EA</option>');
                self._metricSelect.append('<option value="quota">\u05DE\u05DB\u05E1\u05D4</option>');
                self._metricSelect.append('<option value="pct">% \u05E0\u05D9\u05E6\u05D5\u05DC</option>');
                self._metricSelect.val(self.options.metric);
                self._metricSelect.on('change', function () {
                    self.options.metric = this.value;
                    self._render();
                });
                controls.append(self._metricSelect);

                controls.append($('<span style="margin-right:16px;">\u05E1\u05D9\u05E0\u05D5\u05DF:</span>'));
                self._siteInput = $('<input class="mm20-search-input" type="text" style="width:120px;" placeholder="\u05D4\u05DB\u05DC" dir="rtl" />');
                self._siteInput.val(self.options.siteFilter);
                self._siteInput.on('input', function () {
                    self.options.siteFilter = this.value;
                    self._render();
                });
                controls.append(self._siteInput);

                el.append(controls);

                // ── Grid container ──
                self._gridEl = $('<div class="mm20-hm-scroll" style="overflow:auto; flex:1;"></div>');
                el.append(self._gridEl);

                // ── Color legend ──
                var legend = $('<div class="mm20-hm-legend"></div>');
                legend.append($('<span>\u05E0\u05DE\u05D5\u05DA</span>'));
                legend.append($('<div class="mm20-hm-legend-bar"></div>'));
                legend.append($('<span>\u05D2\u05D1\u05D5\u05D4</span>'));
                el.append(legend);

                // ── Tooltip (hidden) ──
                self._tooltipEl = $('<div class="mm20-tooltip" style="display:none; position:fixed; z-index:200; background:#0F2940; border:1px solid #5BC0EB; border-radius:4px; padding:4px 8px; font-size:11px; color:#ECF0F1; pointer-events:none;"></div>');
                $('body').append(self._tooltipEl);

                // ── Bus subscriptions ──
                var bus = self.options.bus;
                if (bus) {
                    self._onSiteSelected = function (d) {
                        self.options.siteFilter = d.siteId;
                        self._siteInput.val(d.siteId);
                        self._render();
                    };
                    bus.on('site:selected', self._onSiteSelected, self);
                }

                // ── Initial render ──
                self._render();

            } catch (e) {
                MM.shield.log('heatmap', '_create', e);
                MM.shield.renderFallback(self.element, 'heatmap', e);
            }
        },


        // ─────────────────────────────────────
        //  Render heatmap grid
        // ─────────────────────────────────────

        _render: function () {
            var self = this;
            var gridEl = self._gridEl;
            gridEl.empty();

            var sites = self.options.sites || MM.SITES;
            var data = self.options.data;
            var metric = self.options.metric;
            var filter = (self.options.siteFilter || '').toLowerCase();

            // Generate demo data if needed
            if (!data && self.options.demoMode) {
                data = MM.demo.generateSites(sites);
            }
            if (!data) {
                gridEl.html('<div class="mm20-tags-placeholder">\u05D0\u05D9\u05DF \u05E0\u05EA\u05D5\u05E0\u05D9\u05DD \u05DC\u05DE\u05E4\u05EA \u05D7\u05D5\u05DD</div>');
                return;
            }

            // Build table
            var table = $('<table class="mm20-log-table" style="border-collapse:separate; border-spacing:2px;"></table>');

            // Header row: months
            var thead = $('<thead><tr><th style="min-width:100px;">\u05D9\u05D7\u05D9\u05D3\u05D4</th></tr></thead>');
            var headerRow = thead.find('tr');
            for (var m = 0; m < 12; m++) {
                headerRow.append($('<th style="width:30px; text-align:center; font-size:10px;"></th>').text(MM.MONTHS_HE[m]));
            }
            table.append(thead);

            // Body: one row per unit
            var tbody = $('<tbody></tbody>');
            var globalMax = self._getGlobalMax(sites, data, metric);

            for (var s = 0; s < sites.length; s++) {
                var site = sites[s];
                if (filter && site.id.toLowerCase().indexOf(filter) < 0 && site.name.toLowerCase().indexOf(filter) < 0) continue;

                var siteData = data[site.id];
                if (!siteData) continue;

                for (var u = 0; u < site.units.length; u++) {
                    var unitData = siteData[u];
                    if (!unitData) continue;

                    var tr = $('<tr></tr>');
                    tr.append($('<td style="font-size:11px; white-space:nowrap;"></td>').text(site.units[u]));

                    var monthly = unitData.monthly || [];
                    for (var mm = 0; mm < 12; mm++) {
                        var val = (monthly[mm] && monthly[mm].value !== undefined) ? monthly[mm].value : 0;
                        var color = self._valueToColor(val, globalMax);
                        var cell = $('<td class="mm20-hm-cell"></td>')
                            .css('background', color)
                            .attr('data-val', val)
                            .attr('data-unit', site.units[u])
                            .attr('data-month', MM.MONTHS_HE[mm]);

                        // Tooltip events
                        (function (v, uname, mname) {
                            cell.on('mouseenter', function (e) {
                                self._tooltipEl.text(uname + ' | ' + mname + ': ' + MM.formatNum(v, 0))
                                    .css({ left: e.pageX + 10, top: e.pageY - 20 })
                                    .show();
                            });
                            cell.on('mousemove', function (e) {
                                self._tooltipEl.css({ left: e.pageX + 10, top: e.pageY - 20 });
                            });
                            cell.on('mouseleave', function () {
                                self._tooltipEl.hide();
                            });
                        })(val, site.units[u], MM.MONTHS_HE[mm]);

                        tr.append(cell);
                    }
                    tbody.append(tr);
                }
            }

            table.append(tbody);
            gridEl.append(table);
        },


        // ─────────────────────────────────────
        //  Color interpolation
        // ─────────────────────────────────────

        _getGlobalMax: function (sites, data, metric) {
            var max = 1;
            for (var s = 0; s < sites.length; s++) {
                var sd = data[sites[s].id];
                if (!sd) continue;
                for (var u = 0; u < sites[s].units.length; u++) {
                    var ud = sd[u];
                    if (!ud || !ud.monthly) continue;
                    for (var m = 0; m < ud.monthly.length; m++) {
                        var v = ud.monthly[m].value || 0;
                        if (v > max) max = v;
                    }
                }
            }
            return max;
        },

        /**
         * Map value to color: green(low) → yellow(mid) → red(high).
         */
        _valueToColor: function (val, max) {
            if (max <= 0) return 'rgba(255,255,255,0.1)';
            var ratio = Math.min(val / max, 1);

            var r, g, b;
            if (ratio < 0.5) {
                // green → yellow
                var t = ratio * 2;
                r = Math.round(46 + (243 - 46) * t);
                g = Math.round(204 + (156 - 204) * t);
                b = Math.round(113 + (18 - 113) * t);
            } else {
                // yellow → red
                var t2 = (ratio - 0.5) * 2;
                r = Math.round(243 + (231 - 243) * t2);
                g = Math.round(156 + (76 - 156) * t2);
                b = Math.round(18 + (60 - 18) * t2);
            }
            return 'rgb(' + r + ',' + g + ',' + b + ')';
        },


        // ═══════════════════════════════════════
        //  _setOption
        // ═══════════════════════════════════════

        _setOption: function (key, value) {
            this._super(key, value);

            if (key === 'data' || key === 'metric' || key === 'siteFilter') {
                this._render();
            }
        },


        // ═══════════════════════════════════════
        //  _destroy
        // ═══════════════════════════════════════

        _destroy: function () {
            this._destroyed = true;

            var bus = this.options.bus;
            if (bus && this._onSiteSelected) {
                bus.off('site:selected', this._onSiteSelected);
            }

            if (this._tooltipEl) {
                this._tooltipEl.remove();
                this._tooltipEl = null;
            }

            this.element.empty().removeClass('mm20-heatmap-root');
        }
    });

})(window.jQuery);
