/**
 * ═══════════════════════════════════════════════════════
 *  mm20-alerts.js  —  Alert Engine Widget
 * ═══════════════════════════════════════════════════════
 *  Threshold-based alert evaluation, push notifications,
 *  active alert list, alert sound.
 *
 *  jQuery widget: mm20.alerts
 *  Version: 20.0.R1  |  ES5 only
 * ═══════════════════════════════════════════════════════
 */
(function ($) {
    'use strict';

    if (!$ || !$.widget) return;
    var MM = window.MM20;
    if (!MM) { console.error('[mm20-alerts] MM20 core not loaded'); return; }

    $.widget('mm20.mm20Alerts', {

        options: {
            bus:          null,
            sites:        null,
            data:         null,
            demoMode:     false,
            quotaPct:     90,
            hoursMax:     1000,
            staleSec:     300,
            soundEnabled: false,
            pushEnabled:  false
        },

        _alerts: null,       // array of active alerts
        _audioCtx: null,
        _destroyed: false,

        // ═══════════════════════════════════════
        //  _create
        // ═══════════════════════════════════════

        _create: function () {
            var self = this;
            self._destroyed = false;
            self._alerts = [];

            try {
                var el = self.element;
                el.addClass('mm20-alerts-root');

                // ── Header toolbar ──
                var toolbar = $('<div class="mm20-toolbar"></div>');
                toolbar.append($('<span style="font-weight:600;">\u05D4\u05EA\u05E8\u05D0\u05D5\u05EA \u05E4\u05E2\u05D9\u05DC\u05D5\u05EA</span>'));

                self._countBadge = $('<span class="mm20-version-badge" style="margin-right:8px;">0</span>');
                toolbar.append(self._countBadge);

                var clearBtn = $('<button class="mm20-sort-btn">\u05E0\u05E7\u05D4</button>');
                clearBtn.on('click', function () { self._clearAlerts(); });
                toolbar.append(clearBtn);

                el.append(toolbar);

                // ── Alert list ──
                self._listEl = $('<div class="mm20-alert-list"></div>');
                el.append(self._listEl);

                // ── Empty state ──
                self._emptyMsg = $('<div class="mm20-tags-placeholder" style="padding:30px;">\u05D0\u05D9\u05DF \u05D4\u05EA\u05E8\u05D0\u05D5\u05EA \u05E4\u05E2\u05D9\u05DC\u05D5\u05EA</div>');
                self._listEl.append(self._emptyMsg);

                // ── Bus subscriptions ──
                var bus = self.options.bus;
                if (bus) {
                    self._onDemoToggle = function (d) {
                        self.options.demoMode = d.enabled;
                    };
                    bus.on('demo:toggle', self._onDemoToggle, self);
                }

                // Request push notification permission
                if (self.options.pushEnabled) {
                    self._requestNotificationPermission();
                }

            } catch (e) {
                MM.shield.log('alerts', '_create', e);
                MM.shield.renderFallback(self.element, 'alerts', e);
            }
        },


        // ─────────────────────────────────────
        //  Evaluate alerts against data
        // ─────────────────────────────────────

        _evaluate: function () {
            var self = this;
            var data = self.options.data;
            if (!data) return;

            var sites = self.options.sites || MM.SITES;
            var now = new Date().toISOString();

            for (var s = 0; s < sites.length; s++) {
                var site = sites[s];
                var siteData = data[site.id];
                if (!siteData) continue;

                for (var u = 0; u < site.units.length; u++) {
                    var ud = siteData[u];
                    if (!ud) continue;

                    var unitKey = MM.unitKey(site.id, u);
                    var unitLabel = site.name + ' \u2014 ' + site.units[u];

                    // Quota threshold alert
                    if (ud.pct >= self.options.quotaPct) {
                        self._fireAlert({
                            unitKey: unitKey,
                            level: ud.pct >= 95 ? 'critical' : 'warn',
                            msg: '\u05E0\u05D9\u05E6\u05D5\u05DC \u05DE\u05DB\u05E1\u05D4 ' + MM.formatNum(ud.pct, 1) + '%',
                            source: unitLabel,
                            ts: now
                        });
                    }

                    // Hours max alert
                    if (self.options.hoursMax > 0 && ud.hours >= self.options.hoursMax) {
                        self._fireAlert({
                            unitKey: unitKey,
                            level: 'critical',
                            msg: '\u05D7\u05E8\u05D9\u05D2\u05D4 \u05DE\u05E9\u05E2\u05D5\u05EA \u05DE\u05E7\u05E1\u05D9\u05DE\u05D5\u05DD (' + MM.formatNum(ud.hours, 0) + ')',
                            source: unitLabel,
                            ts: now
                        });
                    }

                    // Stale data alert
                    if (self.options.staleSec > 0 && ud.ts) {
                        var age = (new Date().getTime() - new Date(ud.ts).getTime()) / 1000;
                        if (age > self.options.staleSec) {
                            self._fireAlert({
                                unitKey: unitKey,
                                level: 'warn',
                                msg: '\u05E0\u05EA\u05D5\u05E0\u05D9\u05DD \u05DE\u05D9\u05D5\u05E9\u05E0\u05D9\u05DD (' + Math.round(age) + 's)',
                                source: unitLabel,
                                ts: now
                            });
                        }
                    }
                }
            }
        },


        // ─────────────────────────────────────
        //  Fire a single alert
        // ─────────────────────────────────────

        _fireAlert: function (alert) {
            var self = this;

            // Deduplicate: don't repeat same unitKey+msg within 60s
            for (var i = self._alerts.length - 1; i >= 0; i--) {
                var existing = self._alerts[i];
                if (existing.unitKey === alert.unitKey && existing.msg === alert.msg) {
                    var dt = new Date(alert.ts).getTime() - new Date(existing.ts).getTime();
                    if (dt < 60000) return; // skip duplicate
                }
            }

            self._alerts.push(alert);
            if (self._alerts.length > 200) self._alerts.shift();

            // Update DOM
            self._renderAlert(alert);
            self._countBadge.text(self._alerts.length);
            self._emptyMsg.hide();

            // Emit to bus
            if (self.options.bus) {
                self.options.bus.emit('alert:fired', alert);
                self.options.bus.emit('log:entry', {
                    level: alert.level,
                    source: 'alerts:' + alert.source,
                    msg: alert.msg,
                    ts: alert.ts
                });
            }

            // Sound
            if (self.options.soundEnabled && alert.level === 'critical') {
                self._playBeep();
            }

            // Push notification
            if (self.options.pushEnabled && alert.level === 'critical') {
                self._sendPush(alert);
            }
        },


        // ─────────────────────────────────────
        //  Render alert row in DOM
        // ─────────────────────────────────────

        _renderAlert: function (alert) {
            var row = $('<div class="mm20-alert-row"></div>');
            if (alert.level === 'critical') row.addClass('mm20-alert-row--critical');
            else if (alert.level === 'warn') row.addClass('mm20-alert-row--warn');

            row.append($('<span class="mm20-alert-time"></span>').text(MM.formatDate(alert.ts, 'time')));
            row.append($('<span class="mm20-alert-source"></span>').text(alert.source || ''));
            row.append($('<span class="mm20-alert-msg"></span>').text(alert.msg));

            // Prepend (newest on top)
            this._listEl.prepend(row);
        },


        // ─────────────────────────────────────
        //  Clear alerts
        // ─────────────────────────────────────

        _clearAlerts: function () {
            this._alerts = [];
            this._listEl.empty();
            this._listEl.append(this._emptyMsg.show());
            this._countBadge.text('0');
        },


        // ─────────────────────────────────────
        //  Sound (Web Audio API beep)
        // ─────────────────────────────────────

        _playBeep: function () {
            try {
                if (!this._audioCtx) {
                    var AC = window.AudioContext || window.webkitAudioContext;
                    if (!AC) return;
                    this._audioCtx = new AC();
                }
                var ctx = this._audioCtx;
                var osc = ctx.createOscillator();
                var gain = ctx.createGain();
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.frequency.value = 880;
                gain.gain.value = 0.15;
                osc.start(ctx.currentTime);
                osc.stop(ctx.currentTime + 0.15);
            } catch (e) {
                // Audio not available — silent fail
            }
        },


        // ─────────────────────────────────────
        //  Push Notifications
        // ─────────────────────────────────────

        _requestNotificationPermission: function () {
            if (typeof Notification !== 'undefined' && Notification.permission === 'default') {
                try { Notification.requestPermission(); } catch (e) { /* IE11 */ }
            }
        },

        _sendPush: function (alert) {
            try {
                if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
                    new Notification('\u05D4\u05EA\u05E8\u05D0\u05EA \u05DE\u05D5\u05D2\u05D1\u05DC\u05D5\u05EA', {
                        body: alert.source + ': ' + alert.msg,
                        icon: '/PIVision/Scripts/app/editor/symbols/ext/icons/mm20.png',
                        tag: alert.unitKey
                    });
                }
            } catch (e) {
                // Push not supported — silent fail
            }
        },


        // ═══════════════════════════════════════
        //  _setOption
        // ═══════════════════════════════════════

        _setOption: function (key, value) {
            this._super(key, value);

            if (key === 'data') {
                this._evaluate();
            } else if (key === 'pushEnabled' && value) {
                this._requestNotificationPermission();
            }
        },


        // ═══════════════════════════════════════
        //  _destroy
        // ═══════════════════════════════════════

        _destroy: function () {
            this._destroyed = true;

            var bus = this.options.bus;
            if (bus && this._onDemoToggle) {
                bus.off('demo:toggle', this._onDemoToggle);
            }

            if (this._audioCtx) {
                try { this._audioCtx.close(); } catch (e) {}
                this._audioCtx = null;
            }

            this._alerts = null;
            this.element.empty().removeClass('mm20-alerts-root');
        }
    });

})(window.jQuery);
